const index = 10;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CN9OiVMH.js')).default;
const imports = ["_app/immutable/nodes/10.UuTAj2iN.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DX-Oc8op.js","_app/immutable/chunks/3zx2OM-S.js","_app/immutable/chunks/Dwjkgfq3.js","_app/immutable/chunks/z8oQ6GeD.js","_app/immutable/chunks/ugyboSLg.js","_app/immutable/chunks/lPcixCUF.js","_app/immutable/chunks/CUm0MUH_.js","_app/immutable/chunks/BrzuSUaY.js","_app/immutable/chunks/BQu96azb.js","_app/immutable/chunks/Bwnq7jH9.js","_app/immutable/chunks/BID1lDIu.js","_app/immutable/chunks/dcpnCTTX.js","_app/immutable/chunks/DkmbWJ8q.js","_app/immutable/chunks/DdD0hk9E.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=10-3ZPhDeFG.js.map
