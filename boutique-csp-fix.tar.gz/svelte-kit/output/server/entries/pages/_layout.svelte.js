import { I as getContext, p as push, J as store_get, g as push_element, j as pop_element, u as slot, K as unsubscribe_stores, m as bind_props, f as pop, F as FILENAME } from "../../chunks/index3.js";
import "../../chunks/client.js";
import "clsx";
import "../../chunks/badge.js";
const getStores = () => {
  const stores$1 = getContext("__svelte__");
  return {
    /** @type {typeof page} */
    page: {
      subscribe: stores$1.page.subscribe
    },
    /** @type {typeof navigating} */
    navigating: {
      subscribe: stores$1.navigating.subscribe
    },
    /** @type {typeof updated} */
    updated: stores$1.updated
  };
};
const page = {
  subscribe(fn) {
    const store = get_store("page");
    return store.subscribe(fn);
  }
};
function get_store(name) {
  try {
    return getStores()[name];
  } catch {
    throw new Error(
      `Cannot subscribe to '${name}' store on the server outside of a Svelte component, as it is bound to the current request via component context. This prevents state from leaking between users.For more information, see https://svelte.dev/docs/kit/state-management#avoid-shared-state-on-the-server`
    );
  }
}
_layout[FILENAME] = "src/routes/+layout.svelte";
function _layout($$payload, $$props) {
  push(_layout);
  var $$store_subs;
  let currentPath;
  let data = $$props["data"];
  data.user;
  currentPath = store_get($$store_subs ??= {}, "$page", page).url.pathname;
  currentPath.startsWith("/client-portal");
  $$payload.out.push(`<div class="min-h-screen bg-gradient-to-br from-black via-slate-900 to-black">`);
  push_element($$payload, "div", 183, 0);
  $$payload.out.push(`<div class="absolute inset-0 opacity-30">`);
  push_element($$payload, "div", 185, 1);
  $$payload.out.push(`<div class="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-slate-800/20 to-purple-800/20">`);
  push_element($$payload, "div", 186, 2);
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` <div class="absolute inset-0" style="background-image: radial-gradient(circle at 25% 25%, rgba(30, 58, 138, 0.1) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(15, 23, 42, 0.1) 0%, transparent 50%);">`);
  push_element($$payload, "div", 187, 2);
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` `);
  {
    $$payload.out.push("<!--[!-->");
    $$payload.out.push(`<main class="min-h-screen flex items-center justify-center p-4">`);
    push_element($$payload, "main", 304, 2);
    $$payload.out.push(`<!---->`);
    slot($$payload, $$props, "default", {}, null);
    $$payload.out.push(`<!----></main>`);
    pop_element();
  }
  $$payload.out.push(`<!--]--></div>`);
  pop_element();
  $$payload.out.push(` `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  if ($$store_subs) unsubscribe_stores($$store_subs);
  bind_props($$props, { data });
  pop();
}
_layout.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _layout as default
};
