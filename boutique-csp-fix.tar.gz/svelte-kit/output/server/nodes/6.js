

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/client-portal/components-showcase/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.Bkv7npHN.js","_app/immutable/chunks/CgY5D-bl.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/chunks/BRn0EAu4.js","_app/immutable/chunks/D0VStH_y.js","_app/immutable/chunks/B3VCqAEP.js","_app/immutable/chunks/D6bItcHM.js","_app/immutable/chunks/ChEOsMF6.js","_app/immutable/chunks/BS_EoU4C.js","_app/immutable/chunks/BZniq_6W.js","_app/immutable/chunks/BmlrIVXS.js","_app/immutable/chunks/DMOjHFq0.js","_app/immutable/chunks/CXYxNt-Z.js"];
export const stylesheets = ["_app/immutable/assets/6.BVjUnL4G.css"];
export const fonts = [];
