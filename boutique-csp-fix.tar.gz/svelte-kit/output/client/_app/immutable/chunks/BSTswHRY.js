import{c as y,l as P,a as C}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{aw as J,ax as E,g as z,s as X,ay as Y,p as k,c as _,f as w,a as g,b as u,d as I,F as f,e as F,az as D,i as Z,aA as $,r as ee,w as K,x as te}from"./dabN1jmf.js";import{I as O,s as Q}from"./ChEOsMF6.js";import{p as h,i as U,r as R,l as W,s as q,c as V}from"./D0VStH_y.js";import{b as M,r as j,c as S}from"./D6bItcHM.js";import{a as ae,c as G}from"./7U4hBtYM.js";import{c as re}from"./lAWnTVRj.js";import{c as se}from"./BmlrIVXS.js";import{a as oe,d as ie,e as H,f as ne,m as le}from"./DnaP8nfx.js";const de=ie({component:"label",parts:["root"]});class B{static create(e){return new B(e)}opts;attachment;constructor(e){this.opts=e,this.attachment=oe(this.opts.ref),this.onmousedown=this.onmousedown.bind(this)}onmousedown(e){e.detail>1&&e.preventDefault()}#e=J(E(()=>({id:this.opts.id.current,[de.root]:"",onmousedown:this.onmousedown,...this.attachment})),"LabelRootState.props");get props(){return z(this.#e)}set props(e){X(this.#e,e)}}p[f]="node_modules/bits-ui/dist/bits/label/components/label.svelte";var ce=C(F("<label><!></label>"),p[f],[[31,1]]);function p(d,e){const r=Y();y(new.target),k(e,!0,p);let s=h(e,"id",19,()=>ne(r)),i=h(e,"ref",15,null),c=R(e,["$$slots","$$events","$$legacy","children","child","id","ref","for"],"restProps");const o=B.create({id:H.with(()=>s()),ref:H.with(()=>i(),t=>i(t))}),n=J(E(()=>le(c,o.props,{for:e.for})),"mergedProps");var v=_(),b=w(v);{var l=t=>{var m=_(),A=w(m);g(()=>D(A,()=>e.child,()=>({props:z(n)})),"render",p,29,1),u(t,m)},a=t=>{var m=ce();M(m,()=>({...z(n),for:e.for}));var A=Z(m);g(()=>D(A,()=>e.children??$),"render",p,32,2),ee(m),u(t,m)};g(()=>U(b,t=>{e.child?t(l):t(a,!1)}),"if",p,28,0)}return u(d,v),I({...P()})}L[f]="node_modules/lucide-svelte/dist/icons/mail.svelte";function L(d,e){y(new.target);const r=W(e,["children","$$slots","$$events","$$legacy"]);k(e,!1,L);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const s=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}]];return g(()=>O(d,q({name:"mail"},()=>r,{get iconNode(){return s},children:K(L,(i,c)=>{var o=_(),n=w(o);Q(n,e,"default",{},null),u(i,o)}),$$slots:{default:!0}})),"component",L,36,0,{componentTag:"Icon"}),I({...P()})}N[f]="node_modules/lucide-svelte/dist/icons/shield.svelte";function N(d,e){y(new.target);const r=W(e,["children","$$slots","$$events","$$legacy"]);k(e,!1,N);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const s=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];return g(()=>O(d,q({name:"shield"},()=>r,{get iconNode(){return s},children:K(N,(i,c)=>{var o=_(),n=w(o);Q(n,e,"default",{},null),u(i,o)}),$$slots:{default:!0}})),"component",N,36,0,{componentTag:"Icon"}),I({...P()})}x[f]="src/lib/components/ui/input/input.svelte";var ue=C(F("<input/>"),x[f],[[23,1]]),fe=C(F("<input/>"),x[f],[[38,1]]);function x(d,e){y(new.target),k(e,!0,x);let r=h(e,"ref",15,null),s=h(e,"value",15),i=h(e,"files",15),c=R(e,["$$slots","$$events","$$legacy","ref","value","type","files","class"],"restProps");var o=_(),n=w(o);{var v=l=>{var a=ue();j(a),M(a,t=>({"data-slot":"input",class:t,type:"file",...c}),[()=>S("selection:bg-primary dark:bg-input/30 selection:text-primary-foreground border-input ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 pt-1.5 text-sm font-medium outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",e.class)]),V(a,t=>r(t),()=>r()),ae(a,i),G(a,s),u(l,a)},b=l=>{var a=fe();j(a),M(a,t=>({"data-slot":"input",class:t,type:e.type,...c}),[()=>S("border-input bg-background selection:bg-primary dark:bg-input/30 selection:text-primary-foreground ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",e.class)]),V(a,t=>r(t),()=>r()),G(a,s),u(l,a)};g(()=>U(n,l=>{te(e.type,"file")?l(v):l(b,!1)}),"if",x,22,0)}return u(d,o),I({...P()})}T[f]="src/lib/components/ui/label/label.svelte";function T(d,e){y(new.target),k(e,!0,T);var r=re(e);let s=h(e,"ref",15,null),i=R(e,["$$slots","$$events","$$legacy","ref","class"],"restProps");var c=_(),o=w(c);{let n=E(()=>S("flex select-none items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-50 group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50",e.class));g(()=>se(o,()=>p,(v,b)=>{r.binding("ref",b,s),b(v,q({"data-slot":"label",get class(){return z(n)}},()=>i,{get ref(){return s()},set ref(l){s(l)}}))}),"component",T,12,0,{componentTag:"LabelPrimitive.Root"})}return u(d,c),I({...P()})}export{x as I,T as L,L as M,N as S};
