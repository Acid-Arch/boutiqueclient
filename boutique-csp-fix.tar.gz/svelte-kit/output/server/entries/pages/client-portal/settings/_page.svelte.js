import { r as sanitize_props, p as push, t as spread_props, l as prevent_snippet_stringification, u as slot, f as pop, F as FILENAME, C as copy_payload, D as assign_payload, m as bind_props, h as head, g as push_element, j as pop_element, k as escape_html, E as attr_class, G as stringify } from "../../../../chunks/index3.js";
import "../../../../chunks/card-title.js";
import "clsx";
import { B as Button } from "../../../../chunks/badge.js";
import "../../../../chunks/label.js";
import { I as Icon } from "../../../../chunks/Icon.js";
Save[FILENAME] = "node_modules/lucide-svelte/dist/icons/save.svelte";
function Save($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Save);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"
      }
    ],
    ["path", { "d": "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7" }],
    ["path", { "d": "M7 3v4a1 1 0 0 0 1 1h7" }]
  ];
  Icon($$payload, spread_props([
    { name: "save" },
    $$sanitized_props,
    {
      /**
       * @component @name Save
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTUuMiAzYTIgMiAwIDAgMSAxLjQuNmwzLjggMy44YTIgMiAwIDAgMSAuNiAxLjRWMTlhMiAyIDAgMCAxLTIgMkg1YTIgMiAwIDAgMS0yLTJWNWEyIDIgMCAwIDEgMi0yeiIgLz4KICA8cGF0aCBkPSJNMTcgMjF2LTdhMSAxIDAgMCAwLTEtMUg4YTEgMSAwIDAgMC0xIDF2NyIgLz4KICA8cGF0aCBkPSJNNyAzdjRhMSAxIDAgMCAwIDEgMWg3IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/save
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Save.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
_page[FILENAME] = "src/routes/client-portal/settings/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  let userSettings;
  let data = $$props["data"];
  let saving = false;
  let saveMessage = "";
  async function saveSettings() {
    console.log("🔥 saveSettings function called!");
    if (saving) return;
    saving = true;
    saveMessage = "";
    try {
      console.log("🔥 Saving settings...", userSettings);
      const response = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile: {
            name: userSettings.profile.name,
            company: userSettings.profile.company
          },
          notifications: userSettings.notifications
        })
      });
      if (response.ok) {
        const result = await response.json();
        saveMessage = "✅ Settings saved successfully!";
        console.log("Settings saved:", result);
        setTimeout(
          () => {
            saveMessage = "";
          },
          3e3
        );
      } else {
        const error = await response.json();
        saveMessage = `❌ Error: ${error.error || "Failed to save settings"}`;
        console.error("Save error:", error);
      }
    } catch (error) {
      saveMessage = "❌ Network error occurred while saving";
      console.error("Network error:", error);
    } finally {
      saving = false;
    }
  }
  userSettings = data.userSettings;
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    head($$payload2, ($$payload3) => {
      $$payload3.title = `<title>Settings - Client Portal</title>`;
    });
    $$payload2.out.push(`<div class="space-y-6">`);
    push_element($$payload2, "div", 83, 0);
    $$payload2.out.push(`<div class="flex items-center justify-between">`);
    push_element($$payload2, "div", 85, 1);
    $$payload2.out.push(`<div>`);
    push_element($$payload2, "div", 86, 2);
    $$payload2.out.push(`<h1 class="text-3xl font-bold text-white">`);
    push_element($$payload2, "h1", 87, 3);
    $$payload2.out.push(`Settings</h1>`);
    pop_element();
    $$payload2.out.push(` <p class="text-slate-300 mt-1">`);
    push_element($$payload2, "p", 88, 3);
    $$payload2.out.push(`Manage your account preferences and configuration</p>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
    $$payload2.out.push(` <div class="flex flex-col items-end gap-2 relative z-10">`);
    push_element($$payload2, "div", 90, 2);
    if (saveMessage) {
      $$payload2.out.push("<!--[-->");
      $$payload2.out.push(`<div${attr_class(`text-sm ${stringify(saveMessage.startsWith("✅") ? "text-green-400" : "text-red-400")}`)}>`);
      push_element($$payload2, "div", 92, 4);
      $$payload2.out.push(`${escape_html(saveMessage)}</div>`);
      pop_element();
    } else {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--> `);
    Button($$payload2, {
      onclick: saveSettings,
      disabled: saving,
      class: "bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed relative z-20",
      children: prevent_snippet_stringification(($$payload3) => {
        Save($$payload3, { class: "w-4 h-4 mr-2" });
        $$payload3.out.push(`<!----> ${escape_html(saving ? "Saving..." : "Save Changes")}`);
      }),
      $$slots: { default: true }
    });
    $$payload2.out.push(`<!----></div>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
    $$payload2.out.push(` `);
    {
      $$payload2.out.push("<!--[!-->");
    }
    $$payload2.out.push(`<!--]--></div>`);
    pop_element();
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  bind_props($$props, { data });
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
