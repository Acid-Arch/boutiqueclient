import { r as sanitize_props, p as push, t as spread_props, l as prevent_snippet_stringification, u as slot, f as pop, F as FILENAME, C as copy_payload, D as assign_payload, h as head, g as push_element, j as pop_element, k as escape_html } from "../../../chunks/index3.js";
import { b as base } from "../../../chunks/paths.js";
import "../../../chunks/client.js";
import { B as Button } from "../../../chunks/badge.js";
import { C as Card, a as Card_header, b as Card_title, c as Card_content } from "../../../chunks/card-title.js";
import "clsx";
import { L as Label, I as Input } from "../../../chunks/label.js";
import { M as Mail, S as Shield, E as Eye } from "../../../chunks/shield.js";
import { I as Icon } from "../../../chunks/Icon.js";
async function signIn(provider, options, authorizationParams) {
  const { callbackUrl, ...rest } = options ?? {};
  const { redirect = true, redirectTo = callbackUrl ?? window.location.href, ...signInParams } = rest;
  const baseUrl = base ?? "";
  const signInUrl = `${baseUrl}/auth/${"signin"}/${provider}`;
  const res = await fetch(`${signInUrl}?${new URLSearchParams(authorizationParams)}`, {
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Auth-Return-Redirect": "1"
    },
    body: new URLSearchParams({
      ...signInParams,
      callbackUrl: redirectTo
    })
  });
  const data = await res.json();
  if (redirect) {
    const url = data.url ?? redirectTo;
    window.location.href = url;
    if (url.includes("#"))
      window.location.reload();
    return;
  }
  const error = new URL(data.url).searchParams.get("error") ?? void 0;
  const code = new URL(data.url).searchParams.get("code") ?? void 0;
  return {
    error,
    code,
    status: res.status,
    ok: res.ok,
    url: error ? null : data.url
  };
}
Chart_column[FILENAME] = "node_modules/lucide-svelte/dist/icons/chart-column.svelte";
function Chart_column($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Chart_column);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M3 3v16a2 2 0 0 0 2 2h16" }],
    ["path", { "d": "M18 17V9" }],
    ["path", { "d": "M13 17V5" }],
    ["path", { "d": "M8 17v-3" }]
  ];
  Icon($$payload, spread_props([
    { name: "chart-column" },
    $$sanitized_props,
    {
      /**
       * @component @name ChartColumn
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMyAzdjE2YTIgMiAwIDAgMCAyIDJoMTYiIC8+CiAgPHBhdGggZD0iTTE4IDE3VjkiIC8+CiAgPHBhdGggZD0iTTEzIDE3VjUiIC8+CiAgPHBhdGggZD0iTTggMTd2LTMiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/chart-column
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Chart_column.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Log_in[FILENAME] = "node_modules/lucide-svelte/dist/icons/log-in.svelte";
function Log_in($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Log_in);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "m10 17 5-5-5-5" }],
    ["path", { "d": "M15 12H3" }],
    ["path", { "d": "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" }]
  ];
  Icon($$payload, spread_props([
    { name: "log-in" },
    $$sanitized_props,
    {
      /**
       * @component @name LogIn
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJtMTAgMTcgNS01LTUtNSIgLz4KICA8cGF0aCBkPSJNMTUgMTJIMyIgLz4KICA8cGF0aCBkPSJNMTUgM2g0YTIgMiAwIDAgMSAyIDJ2MTRhMiAyIDAgMCAxLTIgMmgtNCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/log-in
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Log_in.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Users[FILENAME] = "node_modules/lucide-svelte/dist/icons/users.svelte";
function Users($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Users);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }],
    ["path", { "d": "M16 3.128a4 4 0 0 1 0 7.744" }],
    ["path", { "d": "M22 21v-2a4 4 0 0 0-3-3.87" }],
    ["circle", { "cx": "9", "cy": "7", "r": "4" }]
  ];
  Icon($$payload, spread_props([
    { name: "users" },
    $$sanitized_props,
    {
      /**
       * @component @name Users
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTYgMjF2LTJhNCA0IDAgMCAwLTQtNEg2YTQgNCAwIDAgMC00IDR2MiIgLz4KICA8cGF0aCBkPSJNMTYgMy4xMjhhNCA0IDAgMCAxIDAgNy43NDQiIC8+CiAgPHBhdGggZD0iTTIyIDIxdi0yYTQgNCAwIDAgMC0zLTMuODciIC8+CiAgPGNpcmNsZSBjeD0iOSIgY3k9IjciIHI9IjQiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/users
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Users.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
_page[FILENAME] = "src/routes/login/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  let loginMethod = "oauth";
  let isLoading = false;
  let loginError = "";
  let email = "jorge.test@gmail.com";
  let password = "testpassword123";
  async function handleGoogleSignIn() {
    try {
      await signIn("google", { callbackUrl: "/client-portal" });
    } catch (error) {
      console.error("OAuth signin error:", error);
      loginError = "OAuth signin failed. Please try again.";
    }
  }
  function switchLoginMethod() {
    loginMethod = loginMethod === "oauth" ? "email" : "oauth";
    loginError = "";
    email = "";
    password = "";
  }
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    head($$payload2, ($$payload3) => {
      $$payload3.title = `<title>Login - Client Portal</title>`;
      $$payload3.out.push(`<meta name="description" content="Login to your Client Portal"/>`);
      push_element($$payload3, "meta", 88, 1);
      pop_element();
    });
    $$payload2.out.push(`<div class="min-h-screen flex items-center justify-center p-4">`);
    push_element($$payload2, "div", 92, 0);
    $$payload2.out.push(`<div class="w-full max-w-md space-y-6">`);
    push_element($$payload2, "div", 93, 2);
    $$payload2.out.push(`<div class="text-center">`);
    push_element($$payload2, "div", 95, 3);
    $$payload2.out.push(`<h1 class="text-4xl font-bold text-white mb-2">`);
    push_element($$payload2, "h1", 96, 4);
    $$payload2.out.push(`✨ Client Portal</h1>`);
    pop_element();
    $$payload2.out.push(` <p class="text-slate-300">`);
    push_element($$payload2, "p", 99, 4);
    $$payload2.out.push(`Manage your Instagram accounts with ease</p>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
    $$payload2.out.push(` `);
    Card($$payload2, {
      class: "glass-card border-white/10",
      children: prevent_snippet_stringification(($$payload3) => {
        Card_header($$payload3, {
          class: "space-y-1 text-center",
          children: prevent_snippet_stringification(($$payload4) => {
            Card_title($$payload4, {
              class: "text-2xl text-white",
              children: prevent_snippet_stringification(($$payload5) => {
                $$payload5.out.push(`<!---->Welcome Back`);
              }),
              $$slots: { default: true }
            });
            $$payload4.out.push(`<!----> <p class="text-slate-300">`);
            push_element($$payload4, "p", 108, 5);
            $$payload4.out.push(`Sign in to access your dashboard</p>`);
            pop_element();
          }),
          $$slots: { default: true }
        });
        $$payload3.out.push(`<!----> `);
        Card_content($$payload3, {
          class: "space-y-4",
          children: prevent_snippet_stringification(($$payload4) => {
            if (loginError) {
              $$payload4.out.push("<!--[-->");
              $$payload4.out.push(`<div class="bg-red-500/10 border border-red-500/20 rounded-lg p-3">`);
              push_element($$payload4, "div", 112, 6);
              $$payload4.out.push(`<p class="text-red-400 text-sm">`);
              push_element($$payload4, "p", 113, 7);
              $$payload4.out.push(`${escape_html(loginError || "Authentication failed. Please try again.")}</p>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
            } else {
              $$payload4.out.push("<!--[!-->");
            }
            $$payload4.out.push(`<!--]--> `);
            if (loginMethod === "oauth") {
              $$payload4.out.push("<!--[-->");
              Button($$payload4, {
                onclick: handleGoogleSignIn,
                class: "w-full bg-white hover:bg-gray-50 text-gray-900 font-medium",
                disabled: isLoading,
                children: prevent_snippet_stringification(($$payload5) => {
                  $$payload5.out.push(`<svg class="w-5 h-5 mr-3" viewBox="0 0 24 24">`);
                  push_element($$payload5, "svg", 128, 7);
                  $$payload5.out.push(`<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z">`);
                  push_element($$payload5, "path", 129, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z">`);
                  push_element($$payload5, "path", 130, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z">`);
                  push_element($$payload5, "path", 131, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z">`);
                  push_element($$payload5, "path", 132, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`</svg>`);
                  pop_element();
                  $$payload5.out.push(` Continue with Google`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!----> <div class="relative">`);
              push_element($$payload4, "div", 138, 6);
              $$payload4.out.push(`<div class="absolute inset-0 flex items-center">`);
              push_element($$payload4, "div", 139, 7);
              $$payload4.out.push(`<div class="w-full border-t border-white/10">`);
              push_element($$payload4, "div", 140, 8);
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(` <div class="relative flex justify-center text-sm">`);
              push_element($$payload4, "div", 142, 7);
              $$payload4.out.push(`<span class="bg-transparent px-2 text-slate-400">`);
              push_element($$payload4, "span", 143, 8);
              $$payload4.out.push(`Or continue with email</span>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(` `);
              Button($$payload4, {
                variant: "outline",
                onclick: switchLoginMethod,
                class: "w-full border-white/20 text-white hover:bg-white/10 bg-transparent",
                children: prevent_snippet_stringification(($$payload5) => {
                  Mail($$payload5, { class: "w-4 h-4 mr-2" });
                  $$payload5.out.push(`<!----> Sign in with Email`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!---->`);
            } else {
              $$payload4.out.push("<!--[!-->");
              $$payload4.out.push(`<form class="space-y-4">`);
              push_element($$payload4, "form", 159, 6);
              $$payload4.out.push(`<div>`);
              push_element($$payload4, "div", 160, 7);
              Label($$payload4, {
                for: "email",
                class: "text-slate-300",
                children: prevent_snippet_stringification(($$payload5) => {
                  $$payload5.out.push(`<!---->Email Address`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!----> `);
              Input($$payload4, {
                id: "email",
                type: "email",
                placeholder: "Enter your email",
                required: true,
                class: "bg-white/5 border-white/20 text-white placeholder:text-slate-400",
                get value() {
                  return email;
                },
                set value($$value) {
                  email = $$value;
                  $$settled = false;
                }
              });
              $$payload4.out.push(`<!----></div>`);
              pop_element();
              $$payload4.out.push(` <div>`);
              push_element($$payload4, "div", 172, 7);
              Label($$payload4, {
                for: "password",
                class: "text-slate-300",
                children: prevent_snippet_stringification(($$payload5) => {
                  $$payload5.out.push(`<!---->Password`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!----> <div class="relative">`);
              push_element($$payload4, "div", 174, 8);
              Input($$payload4, {
                id: "password",
                type: "password",
                placeholder: "Enter your password",
                required: true,
                class: "bg-white/5 border-white/20 text-white placeholder:text-slate-400 pr-10",
                get value() {
                  return password;
                },
                set value($$value) {
                  password = $$value;
                  $$settled = false;
                }
              });
              $$payload4.out.push(`<!----> <button type="button" class="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white">`);
              push_element($$payload4, "button", 183, 9);
              $$payload4.out.push(`<!---->`);
              Eye?.($$payload4, { class: "h-4 w-4" });
              $$payload4.out.push(`<!----></button>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(` `);
              Button($$payload4, {
                type: "submit",
                disabled: !email || !password,
                class: "w-full bg-blue-600 hover:bg-blue-700 text-white",
                children: prevent_snippet_stringification(($$payload5) => {
                  {
                    $$payload5.out.push("<!--[!-->");
                    Log_in($$payload5, { class: "w-4 h-4 mr-2" });
                    $$payload5.out.push(`<!----> Sign In`);
                  }
                  $$payload5.out.push(`<!--]-->`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!----></form>`);
              pop_element();
              $$payload4.out.push(` <div class="relative">`);
              push_element($$payload4, "div", 209, 6);
              $$payload4.out.push(`<div class="absolute inset-0 flex items-center">`);
              push_element($$payload4, "div", 210, 7);
              $$payload4.out.push(`<div class="w-full border-t border-white/10">`);
              push_element($$payload4, "div", 211, 8);
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(` <div class="relative flex justify-center text-sm">`);
              push_element($$payload4, "div", 213, 7);
              $$payload4.out.push(`<span class="bg-transparent px-2 text-slate-400">`);
              push_element($$payload4, "span", 214, 8);
              $$payload4.out.push(`Or continue with Google</span>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(`</div>`);
              pop_element();
              $$payload4.out.push(` `);
              Button($$payload4, {
                variant: "outline",
                onclick: switchLoginMethod,
                class: "w-full border-white/20 text-white hover:bg-white/10 bg-transparent",
                children: prevent_snippet_stringification(($$payload5) => {
                  $$payload5.out.push(`<svg class="w-4 h-4 mr-2" viewBox="0 0 24 24">`);
                  push_element($$payload5, "svg", 224, 7);
                  $$payload5.out.push(`<path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z">`);
                  push_element($$payload5, "path", 225, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z">`);
                  push_element($$payload5, "path", 226, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z">`);
                  push_element($$payload5, "path", 227, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`<path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z">`);
                  push_element($$payload5, "path", 228, 8);
                  $$payload5.out.push(`</path>`);
                  pop_element();
                  $$payload5.out.push(`</svg>`);
                  pop_element();
                  $$payload5.out.push(` Back to Google Sign In`);
                }),
                $$slots: { default: true }
              });
              $$payload4.out.push(`<!---->`);
            }
            $$payload4.out.push(`<!--]--> <div class="pt-4 space-y-3">`);
            push_element($$payload4, "div", 235, 5);
            $$payload4.out.push(`<div class="flex items-center text-sm text-slate-300">`);
            push_element($$payload4, "div", 236, 6);
            Users($$payload4, { class: "w-4 h-4 mr-2 text-blue-400" });
            $$payload4.out.push(`<!----> Manage Instagram accounts</div>`);
            pop_element();
            $$payload4.out.push(` <div class="flex items-center text-sm text-slate-300">`);
            push_element($$payload4, "div", 240, 6);
            Chart_column($$payload4, { class: "w-4 h-4 mr-2 text-green-400" });
            $$payload4.out.push(`<!----> Analytics and insights</div>`);
            pop_element();
            $$payload4.out.push(` <div class="flex items-center text-sm text-slate-300">`);
            push_element($$payload4, "div", 244, 6);
            Shield($$payload4, { class: "w-4 h-4 mr-2 text-blue-400" });
            $$payload4.out.push(`<!----> Secure and reliable</div>`);
            pop_element();
            $$payload4.out.push(`</div>`);
            pop_element();
          }),
          $$slots: { default: true }
        });
        $$payload3.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    });
    $$payload2.out.push(`<!----> <div class="text-center text-sm text-slate-400">`);
    push_element($$payload2, "div", 253, 3);
    $$payload2.out.push(`<p>`);
    push_element($$payload2, "p", 254, 4);
    $$payload2.out.push(`Secure login powered by Google OAuth</p>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
    $$payload2.out.push(`</div>`);
    pop_element();
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
