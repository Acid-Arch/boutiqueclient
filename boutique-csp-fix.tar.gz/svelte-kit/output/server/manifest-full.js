export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.svg","test.html"]),
	mimeTypes: {".svg":"image/svg+xml",".html":"text/html"},
	_: {
		client: {start:"_app/immutable/entry/start.Dnevraio.js",app:"_app/immutable/entry/app.Bcw70J_0.js",imports:["_app/immutable/entry/start.Dnevraio.js","_app/immutable/chunks/BsEs7m-G.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/entry/app.Bcw70J_0.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/chunks/CgY5D-bl.js","_app/immutable/chunks/lAWnTVRj.js","_app/immutable/chunks/D0VStH_y.js","_app/immutable/chunks/BmlrIVXS.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js')),
			__memo(() => import('./nodes/5.js')),
			__memo(() => import('./nodes/6.js')),
			__memo(() => import('./nodes/7.js')),
			__memo(() => import('./nodes/8.js')),
			__memo(() => import('./nodes/9.js')),
			__memo(() => import('./nodes/10.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/api/accounts",
				pattern: /^\/api\/accounts\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/_server.ts.js'))
			},
			{
				id: "/api/accounts/available",
				pattern: /^\/api\/accounts\/available\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/available/_server.ts.js'))
			},
			{
				id: "/api/accounts/bulk-field",
				pattern: /^\/api\/accounts\/bulk-field\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/bulk-field/_server.ts.js'))
			},
			{
				id: "/api/accounts/bulk-info",
				pattern: /^\/api\/accounts\/bulk-info\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/bulk-info/_server.ts.js'))
			},
			{
				id: "/api/accounts/bulk",
				pattern: /^\/api\/accounts\/bulk\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/bulk/_server.ts.js'))
			},
			{
				id: "/api/accounts/ownership",
				pattern: /^\/api\/accounts\/ownership\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/ownership/_server.ts.js'))
			},
			{
				id: "/api/accounts/[id]",
				pattern: /^\/api\/accounts\/([^/]+?)\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/_id_/_server.ts.js'))
			},
			{
				id: "/api/accounts/[id]/field",
				pattern: /^\/api\/accounts\/([^/]+?)\/field\/?$/,
				params: [{"name":"id","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/accounts/_id_/field/_server.ts.js'))
			},
			{
				id: "/api/admin/health",
				pattern: /^\/api\/admin\/health\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/admin/health/_server.ts.js'))
			},
			{
				id: "/api/admin/ip-whitelist",
				pattern: /^\/api\/admin\/ip-whitelist\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/admin/ip-whitelist/_server.ts.js'))
			},
			{
				id: "/api/admin/security/logs",
				pattern: /^\/api\/admin\/security\/logs\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/admin/security/logs/_server.ts.js'))
			},
			{
				id: "/api/alerts",
				pattern: /^\/api\/alerts\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/alerts/_server.ts.js'))
			},
			{
				id: "/api/auth/check-ip",
				pattern: /^\/api\/auth\/check-ip\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/check-ip/_server.ts.js'))
			},
			{
				id: "/api/auth/create-test-user",
				pattern: /^\/api\/auth\/create-test-user\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/create-test-user/_server.ts.js'))
			},
			{
				id: "/api/auth/logout",
				pattern: /^\/api\/auth\/logout\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/logout/_server.ts.js'))
			},
			{
				id: "/api/auth/me",
				pattern: /^\/api\/auth\/me\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/me/_server.ts.js'))
			},
			{
				id: "/api/auth/oauth/callback",
				pattern: /^\/api\/auth\/oauth\/callback\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/oauth/callback/_server.ts.js'))
			},
			{
				id: "/api/auth/oauth/google",
				pattern: /^\/api\/auth\/oauth\/google\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/oauth/google/_server.ts.js'))
			},
			{
				id: "/api/auth/oauth/initiate",
				pattern: /^\/api\/auth\/oauth\/initiate\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/oauth/initiate/_server.ts.js'))
			},
			{
				id: "/api/auth/request-ip-access",
				pattern: /^\/api\/auth\/request-ip-access\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/auth/request-ip-access/_server.ts.js'))
			},
			{
				id: "/api/avatar/[username]",
				pattern: /^\/api\/avatar\/([^/]+?)\/?$/,
				params: [{"name":"username","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/avatar/_username_/_server.ts.js'))
			},
			{
				id: "/api/dashboard",
				pattern: /^\/api\/dashboard\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/dashboard/_server.ts.js'))
			},
			{
				id: "/api/debug-env",
				pattern: /^\/api\/debug-env\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/debug-env/_server.ts.js'))
			},
			{
				id: "/api/devices",
				pattern: /^\/api\/devices\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/_server.ts.js'))
			},
			{
				id: "/api/devices/assign",
				pattern: /^\/api\/devices\/assign\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/assign/_server.ts.js'))
			},
			{
				id: "/api/devices/auto-assign",
				pattern: /^\/api\/devices\/auto-assign\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/auto-assign/_server.ts.js'))
			},
			{
				id: "/api/devices/capacity-check",
				pattern: /^\/api\/devices\/capacity-check\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/capacity-check/_server.ts.js'))
			},
			{
				id: "/api/devices/unassign",
				pattern: /^\/api\/devices\/unassign\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/unassign/_server.ts.js'))
			},
			{
				id: "/api/devices/[deviceId]",
				pattern: /^\/api\/devices\/([^/]+?)\/?$/,
				params: [{"name":"deviceId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/_deviceId_/_server.ts.js'))
			},
			{
				id: "/api/devices/[deviceId]/clones",
				pattern: /^\/api\/devices\/([^/]+?)\/clones\/?$/,
				params: [{"name":"deviceId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/devices/_deviceId_/clones/_server.ts.js'))
			},
			{
				id: "/api/errors/report",
				pattern: /^\/api\/errors\/report\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/errors/report/_server.ts.js'))
			},
			{
				id: "/api/export",
				pattern: /^\/api\/export\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/export/_server.ts.js'))
			},
			{
				id: "/api/health",
				pattern: /^\/api\/health\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/health/_server.ts.js'))
			},
			{
				id: "/api/health/ready",
				pattern: /^\/api\/health\/ready\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/health/ready/_server.ts.js'))
			},
			{
				id: "/api/health/simple",
				pattern: /^\/api\/health\/simple\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/health/simple/_server.ts.js'))
			},
			{
				id: "/api/import",
				pattern: /^\/api\/import\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/import/_server.ts.js'))
			},
			{
				id: "/api/login",
				pattern: /^\/api\/login\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/login/_server.ts.js'))
			},
			{
				id: "/api/logout",
				pattern: /^\/api\/logout\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/logout/_server.ts.js'))
			},
			{
				id: "/api/metrics",
				pattern: /^\/api\/metrics\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/metrics/_server.ts.js'))
			},
			{
				id: "/api/scraping/accounts",
				pattern: /^\/api\/scraping\/accounts\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/accounts/_server.ts.js'))
			},
			{
				id: "/api/scraping/analytics/costs",
				pattern: /^\/api\/scraping\/analytics\/costs\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/analytics/costs/_server.ts.js'))
			},
			{
				id: "/api/scraping/bulk",
				pattern: /^\/api\/scraping\/bulk\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/bulk/_server.ts.js'))
			},
			{
				id: "/api/scraping/bulk/start",
				pattern: /^\/api\/scraping\/bulk\/start\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/bulk/start/_server.ts.js'))
			},
			{
				id: "/api/scraping/cost-optimizer",
				pattern: /^\/api\/scraping\/cost-optimizer\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/cost-optimizer/_server.ts.js'))
			},
			{
				id: "/api/scraping/daily-scheduler",
				pattern: /^\/api\/scraping\/daily-scheduler\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/daily-scheduler/_server.ts.js'))
			},
			{
				id: "/api/scraping/dashboard/stats",
				pattern: /^\/api\/scraping\/dashboard\/stats\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/dashboard/stats/_server.ts.js'))
			},
			{
				id: "/api/scraping/enhanced-error-recovery/analytics",
				pattern: /^\/api\/scraping\/enhanced-error-recovery\/analytics\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/enhanced-error-recovery/analytics/_server.ts.js'))
			},
			{
				id: "/api/scraping/enhanced-error-recovery/health-check",
				pattern: /^\/api\/scraping\/enhanced-error-recovery\/health-check\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/enhanced-error-recovery/health-check/_server.ts.js'))
			},
			{
				id: "/api/scraping/enhanced-error-recovery/health",
				pattern: /^\/api\/scraping\/enhanced-error-recovery\/health\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/enhanced-error-recovery/health/_server.ts.js'))
			},
			{
				id: "/api/scraping/enhanced-error-recovery/metrics",
				pattern: /^\/api\/scraping\/enhanced-error-recovery\/metrics\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/enhanced-error-recovery/metrics/_server.ts.js'))
			},
			{
				id: "/api/scraping/enhanced-error-recovery/realtime",
				pattern: /^\/api\/scraping\/enhanced-error-recovery\/realtime\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/enhanced-error-recovery/realtime/_server.ts.js'))
			},
			{
				id: "/api/scraping/growth/[accountId]",
				pattern: /^\/api\/scraping\/growth\/([^/]+?)\/?$/,
				params: [{"name":"accountId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/growth/_accountId_/_server.ts.js'))
			},
			{
				id: "/api/scraping/metrics/[accountId]",
				pattern: /^\/api\/scraping\/metrics\/([^/]+?)\/?$/,
				params: [{"name":"accountId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/metrics/_accountId_/_server.ts.js'))
			},
			{
				id: "/api/scraping/profile/[accountId]",
				pattern: /^\/api\/scraping\/profile\/([^/]+?)\/?$/,
				params: [{"name":"accountId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/profile/_accountId_/_server.ts.js'))
			},
			{
				id: "/api/scraping/sessions",
				pattern: /^\/api\/scraping\/sessions\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/sessions/_server.ts.js'))
			},
			{
				id: "/api/scraping/sessions/[sessionId]",
				pattern: /^\/api\/scraping\/sessions\/([^/]+?)\/?$/,
				params: [{"name":"sessionId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/sessions/_sessionId_/_server.ts.js'))
			},
			{
				id: "/api/scraping/sessions/[sessionId]/control",
				pattern: /^\/api\/scraping\/sessions\/([^/]+?)\/control\/?$/,
				params: [{"name":"sessionId","optional":false,"rest":false,"chained":false}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/sessions/_sessionId_/control/_server.ts.js'))
			},
			{
				id: "/api/scraping/start",
				pattern: /^\/api\/scraping\/start\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/start/_server.ts.js'))
			},
			{
				id: "/api/scraping/websocket",
				pattern: /^\/api\/scraping\/websocket\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/scraping/websocket/_server.ts.js'))
			},
			{
				id: "/api/settings",
				pattern: /^\/api\/settings\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/settings/_server.ts.js'))
			},
			{
				id: "/api/test-db",
				pattern: /^\/api\/test-db\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/test-db/_server.ts.js'))
			},
			{
				id: "/api/test-login",
				pattern: /^\/api\/test-login\/?$/,
				params: [],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/api/test-login/_server.ts.js'))
			},
			{
				id: "/auth/[...auth]",
				pattern: /^\/auth(?:\/([^]*))?\/?$/,
				params: [{"name":"auth","optional":false,"rest":true,"chained":true}],
				page: null,
				endpoint: __memo(() => import('./entries/endpoints/auth/_...auth_/_server.ts.js'))
			},
			{
				id: "/client-portal",
				pattern: /^\/client-portal\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			},
			{
				id: "/client-portal/accounts",
				pattern: /^\/client-portal\/accounts\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/client-portal/analytics",
				pattern: /^\/client-portal\/analytics\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/client-portal/components-showcase",
				pattern: /^\/client-portal\/components-showcase\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/client-portal/design-system",
				pattern: /^\/client-portal\/design-system\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/client-portal/settings",
				pattern: /^\/client-portal\/settings\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/status",
				pattern: /^\/status\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 10 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
