import { j as json } from './index-Djsj11qr.js';
import 'bcrypt';
import './database-CKYbeswu.js';
import './index-Dn7PghUK.js';
import './false-B2gHlHjM.js';
import './status-BUw8K8Dp.js';

const POST = async ({ request }) => {
  {
    return json(
      {
        success: false,
        error: "Not available in production"
      },
      { status: 403 }
    );
  }
};

export { POST };
//# sourceMappingURL=_server.ts-BmFm2FUW.js.map
