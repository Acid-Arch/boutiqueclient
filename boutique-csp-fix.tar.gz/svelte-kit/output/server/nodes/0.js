import * as server from '../entries/pages/_layout.server.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/+layout.server.ts";
export const imports = ["_app/immutable/nodes/0.UDGLqQr-.js","_app/immutable/chunks/CgY5D-bl.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/chunks/BRn0EAu4.js","_app/immutable/chunks/D0VStH_y.js","_app/immutable/chunks/BS_EoU4C.js","_app/immutable/chunks/ChEOsMF6.js","_app/immutable/chunks/D6bItcHM.js","_app/immutable/chunks/BmlrIVXS.js","_app/immutable/chunks/C-BgkKZf.js","_app/immutable/chunks/JYmvOfHC.js","_app/immutable/chunks/BsEs7m-G.js","_app/immutable/chunks/lAWnTVRj.js","_app/immutable/chunks/DnaP8nfx.js","_app/immutable/chunks/BjI-xXPM.js","_app/immutable/chunks/DaamNw8i.js","_app/immutable/chunks/Cyf35JNF.js","_app/immutable/chunks/CXYxNt-Z.js"];
export const stylesheets = ["_app/immutable/assets/0.x1XYEf_w.css"];
export const fonts = [];
