import{aE as h,aF as a,aG as g,aw as w,ax as p,g as E,s as y,x as c,p as N,a as _,w as x,c as v,f as D,b as T,d as C,F as A}from"./dabN1jmf.js";import{i as s,e as M}from"./DnaP8nfx.js";import{c as O,l as $}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{I as S,s as I}from"./ChEOsMF6.js";import{l as R,s as b}from"./D0VStH_y.js";class Q{#e;#t;constructor(t){this.#e=t,this.#t=Symbol(t)}get key(){return this.#t}exists(){return h(this.#t)}get(){const t=a(this.#t);if(t===void 0)throw new Error(`Context "${this.#e}" not found`);return t}getOr(t){const r=a(this.#t);return r===void 0?t:r}set(t){return g(this.#t,t)}}const q=1,V=9,W=11;function i(e){return s(e)&&e.nodeType===q&&typeof e.nodeName=="string"}function l(e){return s(e)&&e.nodeType===V}function k(e){return s(e)&&e.constructor?.name==="VisualViewport"}function F(e){return s(e)&&e.nodeType!==void 0}function f(e){return F(e)&&e.nodeType===W&&"host"in e}function X(e,t){if(!e||!t||!i(e)||!i(t))return!1;const r=t.getRootNode?.();if(e===t||e.contains(t))return!0;if(r&&f(r)){let n=t;for(;n;){if(e===n)return!0;n=n.parentNode||n.host}}return!1}function L(e){return l(e)?e:k(e)?e.document:e?.ownerDocument??document}function B(e){return f(e)?B(e.host):l(e)?e.defaultView??window:i(e)?e.ownerDocument?.defaultView??window:window}function G(e){let t=e.activeElement;for(;t?.shadowRoot;){const r=t.shadowRoot.activeElement;if(r===t)break;t=r}return t}class Y{element;#e=w(p(()=>this.element.current?this.element.current.getRootNode()??document:document),"DOMContext.root");get root(){return E(this.#e)}set root(t){y(this.#e,t)}constructor(t){c(typeof t,"function")?this.element=M.with(t):this.element=t}getDocument=()=>L(this.root);getWindow=()=>this.getDocument().defaultView??window;getActiveElement=()=>G(this.root);isActiveElement=t=>c(t,this.getActiveElement());getElementById(t){return this.root.getElementById(t)}querySelector=t=>this.root?this.root.querySelector(t):null;querySelectorAll=t=>this.root?this.root.querySelectorAll(t):[];setTimeout=(t,r)=>this.getWindow().setTimeout(t,r);clearTimeout=t=>this.getWindow().clearTimeout(t)}o[A]="node_modules/lucide-svelte/dist/icons/settings.svelte";function o(e,t){O(new.target);const r=R(t,["children","$$slots","$$events","$$legacy"]);N(t,!1,o);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const n=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"}],["circle",{cx:"12",cy:"12",r:"3"}]];return _(()=>S(e,b({name:"settings"},()=>r,{get iconNode(){return n},children:x(o,(m,U)=>{var u=v(),d=D(u);I(d,t,"default",{},null),T(m,u)}),$$slots:{default:!0}})),"component",o,36,0,{componentTag:"Icon"}),C({...$()})}export{Q as C,Y as D,o as S,X as c,B as g};
