import { json } from "@sveltejs/kit";
import { g as getIPWhitelistConfig, e as extractPublicIP } from "../../../../../chunks/ip-utils.js";
import pg from "pg";
const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});
const GET = async ({ request, url }) => {
  try {
    const config = getIPWhitelistConfig();
    const extractedIP = extractPublicIP(request);
    if (!extractedIP) {
      return json({
        success: true,
        ip: null,
        isPublic: false,
        source: "unknown",
        isWhitelisted: false,
        reason: "Could not determine public IP address",
        config: {
          enabled: config.enabled,
          mode: config.mode
        }
      });
    }
    const { ip: publicIP, source } = extractedIP;
    let isWhitelisted = false;
    let matchedRules = [];
    let groups = [];
    let expiresAt = null;
    if (config.enabled) ;
    let recentAttempts = 0;
    let isRateLimited = false;
    if (config.enabled) ;
    return json({
      success: true,
      ip: publicIP,
      source,
      isPublic: extractedIP.isPublic,
      version: extractedIP.version,
      isWhitelisted,
      matchedRules,
      groups,
      expiresAt,
      config: {
        enabled: config.enabled,
        mode: config.mode,
        devBypass: config.devBypass && process.env.NODE_ENV === "development"
      },
      security: {
        recentAttempts,
        isRateLimited
      }
    });
  } catch (error) {
    console.error("Check IP API error:", error);
    return json(
      {
        success: false,
        error: "Internal server error"
      },
      { status: 500 }
    );
  }
};
const POST = async ({ request }) => {
  try {
    const { ip } = await request.json();
    if (!ip) {
      return json(
        {
          success: false,
          error: "IP address is required"
        },
        { status: 400 }
      );
    }
    const config = getIPWhitelistConfig();
    let isWhitelisted = false;
    let matchedRules = [];
    if (config.enabled) ;
    return json({
      success: true,
      ip,
      isWhitelisted,
      matchedRules,
      config: {
        enabled: config.enabled,
        mode: config.mode
      }
    });
  } catch (error) {
    console.error("Check IP POST API error:", error);
    return json(
      {
        success: false,
        error: "Internal server error"
      },
      { status: 500 }
    );
  }
};
export {
  GET,
  POST
};
