import 'clsx';
import { n as noop } from './index3-0vHBXF6s.js';

const is_legacy = noop.toString().includes("$$") || /function \w+\(\) \{\}/.test(noop.toString());
if (is_legacy) {
  ({
    url: new URL("https://example.com")
  });
}
//# sourceMappingURL=state.svelte-Cinh-8k8.js.map
