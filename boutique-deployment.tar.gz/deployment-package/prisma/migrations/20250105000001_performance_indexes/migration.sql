-- Performance optimization indexes for common query patterns

-- IgAccount performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_status_active_accounts" ON "ig_accounts"("status", "created_at") WHERE "status" != 'Unused';
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_owner_status_active" ON "ig_accounts"("ownerId", "status") WHERE "ownerId" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_assignment_lookup" ON "ig_accounts"("assigned_device_id", "assigned_clone_number", "status") WHERE "assigned_device_id" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_login_tracking" ON "ig_accounts"("login_timestamp", "status") WHERE "login_timestamp" IS NOT NULL;

-- User performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_active_role_lookup" ON "users"("is_active", "role", "created_at") WHERE "is_active" = true;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_login_activity" ON "users"("last_login_at", "last_active_at") WHERE "last_login_at" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_security_lookup" ON "users"("email", "is_active", "locked_until") WHERE "is_active" = true;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_2fa_enabled" ON "users"("is_two_factor_enabled", "email_verified") WHERE "is_two_factor_enabled" = true;

-- Login attempts performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_login_attempts_security_analysis" ON "login_attempts"("ip_address", "success", "timestamp") WHERE "success" = false;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_login_attempts_user_timeline" ON "login_attempts"("user_id", "timestamp", "success") WHERE "user_id" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_login_attempts_failed_by_email" ON "login_attempts"("email", "timestamp") WHERE "success" = false;

-- Audit logs performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_audit_logs_user_event_timeline" ON "audit_logs"("user_id", "event_type", "timestamp") WHERE "user_id" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_audit_logs_security_events" ON "audit_logs"("event_type", "success", "timestamp") WHERE "event_type" IN ('LOGIN_FAILURE', 'LOGIN_BLOCKED_RATE_LIMIT', 'ACCOUNT_LOCKED');
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_audit_logs_ip_analysis" ON "audit_logs"("ip_address", "timestamp", "success") WHERE "ip_address" IS NOT NULL;

-- Session management performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_user_sessions_active_cleanup" ON "user_sessions"("expires_at", "active") WHERE "active" = true;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_user_sessions_user_active" ON "user_sessions"("user_id", "active", "last_activity") WHERE "active" = true;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_user_sessions_device_tracking" ON "user_sessions"("user_id", "ip_address", "created_at");

-- Auth.js sessions performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_sessions_expiry_cleanup" ON "sessions"("expires") WHERE "expires" > CURRENT_TIMESTAMP;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_accounts_user_provider" ON "accounts"("user_id", "provider", "type");

-- Password reset tokens cleanup and security
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_password_reset_tokens_cleanup" ON "password_reset_tokens"("expires_at", "used") WHERE "used" = false;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_password_reset_tokens_security" ON "password_reset_tokens"("user_id", "ip_address", "created_at");

-- Clone inventory performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_clone_inventory_available_devices" ON "clone_inventory"("clone_status", "device_id") WHERE "clone_status" = 'Available';
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_clone_inventory_health_monitoring" ON "clone_inventory"("clone_health", "last_scanned") WHERE "clone_health" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_clone_inventory_assignment_lookup" ON "clone_inventory"("device_id", "clone_status", "current_account");

-- Scraping sessions performance indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_scraping_sessions_active_monitoring" ON "scraping_sessions"("status", "created_at") WHERE "status" IN ('PENDING', 'INITIALIZING', 'RUNNING');
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_scraping_sessions_completion_analysis" ON "scraping_sessions"("session_type", "status", "end_time");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_scraping_sessions_cost_tracking" ON "scraping_sessions"("trigger_source", "estimated_cost", "created_at");

-- Warmup accounts performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_warmup_accounts_device_package" ON "warmup_accounts"("assigned_device_id", "package_name") WHERE "assigned_device_id" IS NOT NULL;

-- User preferences performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_user_preferences_key_value_lookup" ON "user_preferences"("preference_key", "preference_value" varchar_pattern_ops);

-- Full-text search indexes for common search operations
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_username_search" ON "ig_accounts" USING gin(to_tsvector('english', "instagram_username"));
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_name_search" ON "users" USING gin(to_tsvector('english', coalesce("first_name", '') || ' ' || coalesce("last_name", '') || ' ' || coalesce("company", '')));

-- Partial indexes for common filtering scenarios
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_shared_visible" ON "ig_accounts"("visibility", "is_shared", "accountType") WHERE "visibility" != 'PRIVATE' OR "is_shared" = true;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_users_locked_accounts" ON "users"("locked_until", "login_attempts") WHERE "locked_until" > CURRENT_TIMESTAMP;

-- Compound indexes for dashboard queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_ig_accounts_dashboard" ON "ig_accounts"("ownerId", "status", "accountType", "created_at") WHERE "ownerId" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_audit_logs_dashboard" ON "audit_logs"("user_id", "timestamp", "event_type", "success") WHERE "user_id" IS NOT NULL AND "timestamp" > CURRENT_TIMESTAMP - INTERVAL '30 days';