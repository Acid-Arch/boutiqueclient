import"./DsnmJJEf.js";import"./DX-Oc8op.js";import{c as p,f as i,a as l}from"./3zx2OM-S.js";import{I as c,s as d}from"./BID1lDIu.js";import{l as m,s as $}from"./Dwjkgfq3.js";function x(s,o){const r=m(o,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const e=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];c(s,$({name:"x"},()=>r,{get iconNode(){return e},children:(a,f)=>{var t=p(),n=i(t);d(n,o,"default",{},null),l(a,t)},$$slots:{default:!0}}))}export{x as X};
