import { a as authHandle } from './auth-D00jg8WF.js';
import './index-Djsj11qr.js';
import './set-cookie-CLsaEPEn.js';
import '@auth/core';
import './index-Dn7PghUK.js';
import './false-B2gHlHjM.js';
import '@auth/core/errors';

const GET = authHandle;
const POST = authHandle;

export { GET, POST };
//# sourceMappingURL=_server.ts-CzViSPTG.js.map
