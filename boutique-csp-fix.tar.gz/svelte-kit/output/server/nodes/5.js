import * as server from '../entries/pages/client-portal/analytics/_page.server.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/client-portal/analytics/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/client-portal/analytics/+page.server.ts";
export const imports = ["_app/immutable/nodes/5.C1Yhc8V4.js","_app/immutable/chunks/CgY5D-bl.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/chunks/BRn0EAu4.js","_app/immutable/chunks/D0VStH_y.js","_app/immutable/chunks/C-BgkKZf.js","_app/immutable/chunks/B3VCqAEP.js","_app/immutable/chunks/D6bItcHM.js","_app/immutable/chunks/CXwT8Hrx.js","_app/immutable/chunks/ChEOsMF6.js","_app/immutable/chunks/BS_EoU4C.js","_app/immutable/chunks/BAygkCF2.js","_app/immutable/chunks/DaamNw8i.js","_app/immutable/chunks/CBKlNd6a.js","_app/immutable/chunks/BkHu7G1a.js"];
export const stylesheets = [];
export const fonts = [];
