import{c as l,l as p}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{p as i,a as d,w as m,c as u,f as _,b as f,d as g,F as v}from"./dabN1jmf.js";import{I as $,s as h}from"./ChEOsMF6.js";import{l as y,s as I}from"./D0VStH_y.js";e[v]="node_modules/lucide-svelte/dist/icons/user.svelte";function e(t,s){l(new.target);const o=y(s,["children","$$slots","$$events","$$legacy"]);i(s,!1,e);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const r=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"}],["circle",{cx:"12",cy:"7",r:"4"}]];return d(()=>$(t,I({name:"user"},()=>o,{get iconNode(){return r},children:m(e,(n,w)=>{var a=u(),c=_(a);h(c,s,"default",{},null),f(n,a)}),$$slots:{default:!0}})),"component",e,36,0,{componentTag:"Icon"}),g({...p()})}export{e as U};
