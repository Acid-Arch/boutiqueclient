import { redirect } from "@sveltejs/kit";
const load = async ({ locals, url }) => {
  throw redirect(302, "/login");
};
export {
  load
};
