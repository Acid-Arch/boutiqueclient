import { p as push, h as head, f as pop, F as FILENAME, g as push_element, j as pop_element } from "../../chunks/index3.js";
import "../../chunks/client.js";
import "../../chunks/card-title.js";
import "clsx";
import "../../chunks/badge.js";
_page[FILENAME] = "src/routes/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Client Portal</title>`;
    $$payload2.out.push(`<meta name="description" content="Boutique Client Portal - Modern Instagram Account Management"/>`);
    push_element($$payload2, "meta", 21, 1);
    pop_element();
  });
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
