import { D as DEV } from './false-B2gHlHjM.js';

const dev = DEV;

export { dev as d };
//# sourceMappingURL=index-Dn7PghUK.js.map
