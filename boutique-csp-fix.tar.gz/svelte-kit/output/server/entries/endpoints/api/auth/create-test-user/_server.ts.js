import { json } from "@sveltejs/kit";
import bcrypt from "bcrypt";
import { prisma } from "../../../../../chunks/database.js";
import { d as dev } from "../../../../../chunks/index.js";
const SALT_ROUNDS = 12;
const SESSION_DURATION = 7 * 24 * 60 * 60 * 1e3;
class AuthService {
  /**
   * Hash a password using bcrypt
   */
  static async hashPassword(password) {
    return bcrypt.hash(password, SALT_ROUNDS);
  }
  /**
   * Verify a password against a hash
   */
  static async verifyPassword(password, hash) {
    return bcrypt.compare(password, hash);
  }
  /**
   * Create a new user
   */
  static async createUser(userData) {
    const hashedPassword = await this.hashPassword(userData.password);
    return prisma.user.create({
      data: {
        email: userData.email,
        username: userData.username,
        passwordHash: hashedPassword,
        firstName: userData.firstName,
        lastName: userData.lastName,
        company: userData.company,
        role: userData.role || "UNAUTHORIZED",
        subscription: userData.subscription || "Basic",
        accountsLimit: userData.accountsLimit || 10
      }
    });
  }
  /**
   * Authenticate user with email/username and password
   */
  static async authenticateUser(emailOrUsername, password) {
    try {
      const user = await prisma.user.findFirst({
        where: {
          OR: [
            { email: emailOrUsername },
            { username: emailOrUsername }
          ],
          isActive: true
        }
      });
      if (!user) {
        return {
          success: false,
          error: "Invalid credentials"
        };
      }
      const isValidPassword = await this.verifyPassword(password, user.passwordHash);
      if (!isValidPassword) {
        return {
          success: false,
          error: "Invalid credentials"
        };
      }
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: /* @__PURE__ */ new Date() }
      });
      const sessionUser = {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        company: user.company,
        avatar: user.avatar,
        role: user.role,
        subscription: user.subscription,
        accountsLimit: user.accountsLimit,
        isActive: user.isActive,
        lastLoginAt: user.lastLoginAt
      };
      return {
        success: true,
        user: sessionUser
      };
    } catch (error) {
      console.error("Prisma authentication failed, trying direct SQL fallback:", error);
      return await this.authenticateUserDirectSQL(emailOrUsername, password);
    }
  }
  /**
   * Direct SQL authentication fallback for when Prisma is not available
   */
  static async authenticateUserDirectSQL(emailOrUsername, password) {
    try {
      const pg = await import("pg");
      const { Client } = pg.default;
      const client = new Client({
        connectionString: process.env.DATABASE_URL || "postgresql://iglogin:boutiquepassword123@5.78.151.248:5432/igloginagent?sslmode=disable&connect_timeout=30"
      });
      await client.connect();
      try {
        const result = await client.query(`
          SELECT 
            id, email, name, company, role, subscription, active, 
            last_login_at, password_hash, avatar_url, model
          FROM users 
          WHERE email = $1 AND active = true
          LIMIT 1
        `, [emailOrUsername]);
        if (result.rows.length === 0) {
          return {
            success: false,
            error: "Invalid credentials"
          };
        }
        const user = result.rows[0];
        const isValidPassword = user.password_hash ? await this.verifyPassword(password, user.password_hash) : false;
        if (!isValidPassword) {
          return {
            success: false,
            error: "Invalid credentials"
          };
        }
        await client.query(`
          UPDATE users 
          SET last_login_at = NOW() 
          WHERE id = $1
        `, [user.id]);
        const sessionUser = {
          id: parseInt(user.id) || 0,
          email: user.email,
          username: user.email,
          // Use email as username since DB doesn't have username
          firstName: user.name ? user.name.split(" ")[0] : null,
          lastName: user.name ? user.name.split(" ").slice(1).join(" ") : null,
          company: user.company,
          avatar: user.avatar_url,
          role: user.role,
          subscription: user.subscription || "Basic",
          accountsLimit: 10,
          // Default value
          isActive: user.active,
          lastLoginAt: user.last_login_at
        };
        console.log("✅ Direct SQL authentication successful for:", user.email, "model:", user.model);
        return {
          success: true,
          user: sessionUser
        };
      } finally {
        await client.end();
      }
    } catch (error) {
      console.error("Direct SQL authentication error:", error);
      return {
        success: false,
        error: "Authentication failed"
      };
    }
  }
  /**
   * Find user by ID
   */
  static async getUserById(userId) {
    try {
      const user = await prisma.user.findFirst({
        where: {
          id: userId,
          isActive: true
        }
      });
      if (!user) {
        return null;
      }
      return {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        company: user.company,
        avatar: user.avatar,
        role: user.role,
        subscription: user.subscription,
        accountsLimit: user.accountsLimit,
        isActive: user.isActive,
        lastLoginAt: user.lastLoginAt
      };
    } catch (error) {
      console.error("Get user error:", error);
      return null;
    }
  }
  /**
   * Generate a secure session token
   */
  static generateSessionToken() {
    const randomBytes = crypto.getRandomValues(new Uint8Array(32));
    return Array.from(randomBytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  /**
   * Create secure session cookie options
   */
  static getSessionCookieOptions() {
    return {
      httpOnly: true,
      secure: !dev,
      // Use secure cookies in production
      sameSite: "lax",
      maxAge: SESSION_DURATION / 1e3,
      // Convert to seconds
      path: "/"
    };
  }
  /**
   * Validate session token format
   */
  static isValidSessionToken(token) {
    return typeof token === "string" && token.length === 64 && /^[a-f0-9]+$/i.test(token);
  }
}
const POST = async ({ request }) => {
  try {
    const { email, username, password, firstName, lastName, company } = await request.json();
    const user = await AuthService.createUser({
      email: email || "test@domain.com",
      username: username || "jorge",
      password: password || "password123",
      firstName: firstName || "Jorge",
      lastName: lastName || "Martinez",
      company: company || "",
      role: "CLIENT",
      subscription: "Premium",
      accountsLimit: 50
    });
    return json({
      success: true,
      message: "Test user created successfully",
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        company: user.company
      }
    });
  } catch (error) {
    console.error("Create test user error:", error);
    if (error.code === "P2002") {
      return json(
        {
          success: false,
          error: "User with this email or username already exists"
        },
        { status: 400 }
      );
    }
    return json(
      {
        success: false,
        error: "Internal server error"
      },
      { status: 500 }
    );
  }
};
export {
  POST
};
