import { p as push, y as spread_attributes, z as clsx, g as push_element, j as pop_element, m as bind_props, f as pop, F as FILENAME } from "./index3.js";
import { c as cn } from "./badge.js";
Card[FILENAME] = "src/lib/components/ui/card/card.svelte";
function Card($$payload, $$props) {
  push(Card);
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card",
      class: clsx(cn("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", className)),
      ...restProps
    },
    null
  )}>`);
  push_element($$payload, "div", 13, 0);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  pop_element();
  bind_props($$props, { ref });
  pop();
}
Card.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Card_content[FILENAME] = "src/lib/components/ui/card/card-content.svelte";
function Card_content($$payload, $$props) {
  push(Card_content);
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card-content",
      class: clsx(cn("px-6", className)),
      ...restProps
    },
    null
  )}>`);
  push_element($$payload, "div", 13, 0);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  pop_element();
  bind_props($$props, { ref });
  pop();
}
Card_content.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Card_description[FILENAME] = "src/lib/components/ui/card/card-description.svelte";
function Card_description($$payload, $$props) {
  push(Card_description);
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<p${spread_attributes(
    {
      "data-slot": "card-description",
      class: clsx(cn("text-muted-foreground text-sm", className)),
      ...restProps
    },
    null
  )}>`);
  push_element($$payload, "p", 13, 0);
  children?.($$payload);
  $$payload.out.push(`<!----></p>`);
  pop_element();
  bind_props($$props, { ref });
  pop();
}
Card_description.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Card_header[FILENAME] = "src/lib/components/ui/card/card-header.svelte";
function Card_header($$payload, $$props) {
  push(Card_header);
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card-header",
      class: clsx(cn("@container/card-header has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6 grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6", className)),
      ...restProps
    },
    null
  )}>`);
  push_element($$payload, "div", 13, 0);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  pop_element();
  bind_props($$props, { ref });
  pop();
}
Card_header.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Card_title[FILENAME] = "src/lib/components/ui/card/card-title.svelte";
function Card_title($$payload, $$props) {
  push(Card_title);
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out.push(`<div${spread_attributes(
    {
      "data-slot": "card-title",
      class: clsx(cn("font-semibold leading-none", className)),
      ...restProps
    },
    null
  )}>`);
  push_element($$payload, "div", 13, 0);
  children?.($$payload);
  $$payload.out.push(`<!----></div>`);
  pop_element();
  bind_props($$props, { ref });
  pop();
}
Card_title.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  Card as C,
  Card_header as a,
  Card_title as b,
  Card_content as c,
  Card_description as d
};
