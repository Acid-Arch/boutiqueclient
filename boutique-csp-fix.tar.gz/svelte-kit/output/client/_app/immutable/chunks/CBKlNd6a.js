import{c as d,l as c}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{p as i,a as l,w as m,c as u,f as _,b as f,d as g,F as h}from"./dabN1jmf.js";import{I as $,s as v}from"./ChEOsMF6.js";import{l as I,s as w}from"./D0VStH_y.js";e[h]="node_modules/lucide-svelte/dist/icons/trending-up.svelte";function e(a,s){d(new.target);const o=I(s,["children","$$slots","$$events","$$legacy"]);i(s,!1,e);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const n=[["path",{d:"M16 7h6v6"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17"}]];return l(()=>$(a,w({name:"trending-up"},()=>o,{get iconNode(){return n},children:m(e,(r,y)=>{var t=u(),p=_(t);v(p,s,"default",{},null),f(r,t)}),$$slots:{default:!0}})),"component",e,36,0,{componentTag:"Icon"}),g({...c()})}export{e as T};
