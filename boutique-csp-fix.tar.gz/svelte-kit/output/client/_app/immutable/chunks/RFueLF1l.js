import{c as i,l}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{p,a as d,w as m,d as _,c as f,f as u,b as v,F as g}from"./dabN1jmf.js";import{I as $,s as h}from"./ChEOsMF6.js";import{l as y,s as A}from"./D0VStH_y.js";t[g]="node_modules/lucide-svelte/dist/icons/activity.svelte";function t(s,a){i(new.target);const o=y(a,["children","$$slots","$$events","$$legacy"]);p(a,!1,t);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const n=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"}]];return d(()=>$(s,A({name:"activity"},()=>o,{get iconNode(){return n},children:m(t,(r,I)=>{var e=f(),c=u(e);h(c,a,"default",{},null),v(r,e)}),$$slots:{default:!0}})),"component",t,36,0,{componentTag:"Icon"}),_({...l()})}export{t as A};
