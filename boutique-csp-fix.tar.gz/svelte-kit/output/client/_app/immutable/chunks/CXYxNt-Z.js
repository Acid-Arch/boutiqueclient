import{c as p,l as c}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{p as i,a as d,w as m,c as _,f,b as g,d as h,F as u}from"./dabN1jmf.js";import{I as $,s as v}from"./ChEOsMF6.js";import{l as I,s as w}from"./D0VStH_y.js";e[u]="node_modules/lucide-svelte/dist/icons/triangle-alert.svelte";function e(s,a){p(new.target);const o=I(a,["children","$$slots","$$events","$$legacy"]);i(a,!1,e);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const r=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}],["path",{d:"M12 9v4"}],["path",{d:"M12 17h.01"}]];return d(()=>$(s,w({name:"triangle-alert"},()=>o,{get iconNode(){return r},children:m(e,(n,y)=>{var t=_(),l=f(t);v(l,a,"default",{},null),g(n,t)}),$$slots:{default:!0}})),"component",e,36,0,{componentTag:"Icon"}),h({...c()})}export{e as T};
