import { json } from "@sveltejs/kit";
import { v as validateIPAccess, b as recordFailedAttempt } from "../../../../chunks/ip-whitelist.js";
import { s as signIn } from "../../../../chunks/auth-production.js";
const POST = async (event) => {
  console.log("🔐 Login API endpoint called");
  const { request } = event;
  let emailOrUsername;
  let password;
  let rememberMe = false;
  try {
    const body = await request.json();
    emailOrUsername = body.emailOrUsername;
    password = body.password;
    rememberMe = body.rememberMe || false;
    if (!emailOrUsername || !password) {
      return json({
        success: false,
        error: "Email and password are required"
      }, { status: 400 });
    }
  } catch (error) {
    return json({
      success: false,
      error: "Invalid JSON in request body"
    }, { status: 400 });
  }
  try {
    console.log("📧 Login attempt for:", emailOrUsername);
    const ipValidation = await validateIPAccess(request, void 0, emailOrUsername.trim());
    if (!ipValidation.allowed) {
      if (ipValidation.publicIP) {
        await recordFailedAttempt(ipValidation.publicIP);
      }
      return json(
        {
          success: false,
          error: "Access denied",
          details: {
            reason: ipValidation.reason,
            publicIP: ipValidation.publicIP,
            code: "IP_ACCESS_DENIED"
          }
        },
        { status: 403 }
      );
    }
    try {
      const authResult = await signIn("credentials", {
        email: emailOrUsername.trim(),
        password,
        redirect: false
        // Don't redirect, return the result
      });
      if (authResult?.error) {
        if (ipValidation.publicIP) {
          await recordFailedAttempt(ipValidation.publicIP);
        }
        return json(
          {
            success: false,
            error: "Invalid credentials"
          },
          { status: 401 }
        );
      }
      return json({
        success: true,
        redirectUrl: "/client-portal"
      });
    } catch (authError) {
      console.error("Auth.js signin error:", authError);
      if (ipValidation.publicIP) {
        await recordFailedAttempt(ipValidation.publicIP);
      }
      return json(
        {
          success: false,
          error: "Authentication failed"
        },
        { status: 401 }
      );
    }
  } catch (error) {
    console.error("Login API error:", error);
    return json(
      {
        success: false,
        error: "Internal server error"
      },
      { status: 500 }
    );
  }
};
export {
  POST
};
