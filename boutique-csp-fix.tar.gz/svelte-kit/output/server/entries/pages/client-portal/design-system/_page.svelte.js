import { p as push, h as head, f as pop, F as FILENAME } from "../../../../chunks/index3.js";
import "../../../../chunks/card-title.js";
import "clsx";
import "../../../../chunks/badge.js";
_page[FILENAME] = "src/routes/client-portal/design-system/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Design System - Client Portal</title>`;
  });
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
