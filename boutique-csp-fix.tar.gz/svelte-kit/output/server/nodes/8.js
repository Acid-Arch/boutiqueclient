import * as server from '../entries/pages/client-portal/settings/_page.server.ts.js';

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/client-portal/settings/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/client-portal/settings/+page.server.ts";
export const imports = ["_app/immutable/nodes/8.DVhNeROC.js","_app/immutable/chunks/CgY5D-bl.js","_app/immutable/chunks/dabN1jmf.js","_app/immutable/chunks/BRn0EAu4.js","_app/immutable/chunks/D0VStH_y.js","_app/immutable/chunks/D6bItcHM.js","_app/immutable/chunks/C-BgkKZf.js","_app/immutable/chunks/B3VCqAEP.js","_app/immutable/chunks/BSTswHRY.js","_app/immutable/chunks/ChEOsMF6.js","_app/immutable/chunks/BS_EoU4C.js","_app/immutable/chunks/7U4hBtYM.js","_app/immutable/chunks/lAWnTVRj.js","_app/immutable/chunks/BmlrIVXS.js","_app/immutable/chunks/DnaP8nfx.js","_app/immutable/chunks/BCcEh3Q1.js"];
export const stylesheets = [];
export const fonts = [];
