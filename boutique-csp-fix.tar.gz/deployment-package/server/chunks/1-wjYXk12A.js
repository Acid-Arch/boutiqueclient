const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-BsgQQUHM.js')).default;
const imports = ["_app/immutable/nodes/1.BpRkxPT5.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DX-Oc8op.js","_app/immutable/chunks/3zx2OM-S.js","_app/immutable/chunks/9ZzghxzE.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-wjYXk12A.js.map
