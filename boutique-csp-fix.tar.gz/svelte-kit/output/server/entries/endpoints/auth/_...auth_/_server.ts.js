import { S as SvelteKitAuth } from "../../../../chunks/index4.js";
const { handle: authHandle } = SvelteKitAuth({
  providers: [
    // Credentials provider for temporary access during IP-only deployment
    {
      id: "test-admin",
      name: "Test Admin Access",
      type: "credentials",
      credentials: {
        username: {
          label: "Username",
          type: "text",
          placeholder: "Enter admin username"
        },
        password: {
          label: "Password",
          type: "password"
        }
      },
      async authorize(credentials) {
        if (credentials?.username === "admin" && credentials?.password === "boutique2024!") {
          return {
            id: "test-admin-001",
            email: "admin@boutique.local",
            name: "Test Admin",
            role: "ADMIN",
            accountLinked: true,
            isNewUser: false
          };
        }
        if (credentials?.username === "client" && credentials?.password === "client2024!") {
          return {
            id: "test-client-001",
            email: "client@boutique.local",
            name: "Test Client",
            role: "CLIENT",
            accountLinked: true,
            isNewUser: false
          };
        }
        return null;
      }
    }
  ],
  // Session configuration
  session: {
    strategy: "jwt",
    maxAge: 24 * 60 * 60,
    // 24 hours for testing
    updateAge: 6 * 60 * 60
    // Update every 6 hours
  },
  // Cookies configuration
  cookies: {
    sessionToken: {
      name: "boutique-session-token",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false,
        // HTTP-only for IP deployment
        domain: void 0
        // No domain for IP-based access
      }
    },
    callbackUrl: {
      name: "boutique-callback-url",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false
      }
    },
    csrfToken: {
      name: "boutique-csrf-token",
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: false
      }
    }
  },
  // No secure cookies for HTTP deployment
  useSecureCookies: false,
  // JWT configuration
  jwt: {
    maxAge: 24 * 60 * 60
    // 24 hours
  },
  // Page configuration
  pages: {
    signIn: "/login",
    error: "/login",
    signOut: "/login"
  },
  // Simplified callbacks for IP-only deployment
  callbacks: {
    async signIn({ user, account }) {
      if (account?.provider === "test-admin") {
        console.log(`IP-only test login: ${user.email}`);
        return true;
      }
      return false;
    },
    async jwt({ token, user, account }) {
      if (account && user) {
        token.userId = user.id;
        token.email = user.email;
        token.name = user.name;
        token.role = user.role;
        token.isNewUser = user.isNewUser || false;
        token.accountLinked = user.accountLinked || true;
        console.log(`JWT created for test user: ${user.email}`);
      }
      return token;
    },
    async session({ session, token }) {
      if (token.userId) {
        session.user.id = token.userId;
        session.user.role = token.role;
        session.user.isNewUser = token.isNewUser;
        session.user.accountLinked = token.accountLinked;
      }
      return session;
    },
    async redirect({ url, baseUrl }) {
      if (url.startsWith("/")) {
        return `${baseUrl}${url}`;
      }
      const returnUrl = new URL(url).searchParams.get("redirectTo") || new URL(url).searchParams.get("callbackUrl");
      if (returnUrl && returnUrl.startsWith("/")) {
        return `${baseUrl}${returnUrl}`;
      }
      return `${baseUrl}/client-portal`;
    }
  },
  // Events for logging
  events: {
    async signIn({ user, account }) {
      console.log(`IP-only deployment sign in: ${user.email} (provider: ${account?.provider})`);
    }
  },
  // Enable debug for IP testing
  debug: true,
  // Trust host for IP-based deployment
  trustHost: true,
  // Secret for JWT signing
  secret: (() => {
    const secret = process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET;
    if (!secret) {
      console.warn("⚠️  WARNING: Using fallback secret for IP-only deployment testing");
      return "ip-only-deployment-test-secret-not-for-production-use-2024-boutique-testing";
    }
    return secret;
  })()
});
console.log(`
⚠️  IP-ONLY DEPLOYMENT AUTH ACTIVE ⚠️
Test credentials:
- Admin: admin / boutique2024!
- Client: client / client2024!

This is TEMPORARY for IP-only testing.
Replace with full OAuth when domain is configured.
`);
const GET = authHandle;
const POST = authHandle;
export {
  GET,
  POST
};
