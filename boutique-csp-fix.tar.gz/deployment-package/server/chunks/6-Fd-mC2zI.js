const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CbTBUVoh.js')).default;
const imports = ["_app/immutable/nodes/6.G-heSNcu.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DX-Oc8op.js","_app/immutable/chunks/3zx2OM-S.js","_app/immutable/chunks/Dwjkgfq3.js","_app/immutable/chunks/BrzuSUaY.js","_app/immutable/chunks/lPcixCUF.js","_app/immutable/chunks/BID1lDIu.js","_app/immutable/chunks/z8oQ6GeD.js","_app/immutable/chunks/BhGjRHH1.js","_app/immutable/chunks/ugyboSLg.js","_app/immutable/chunks/K5chL7Zt.js","_app/immutable/chunks/DkmbWJ8q.js"];
const stylesheets = ["_app/immutable/assets/6.BVjUnL4G.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=6-Fd-mC2zI.js.map
