import { redirect } from "@sveltejs/kit";
import { sequence } from "@sveltejs/kit/hooks";
import { d as dev } from "./index.js";
import { a as authHandle } from "./auth-production.js";
import { l as logger, L as LogLevel } from "./logger.js";
import { d as rateLimitMiddleware } from "./rate-limiter-comprehensive.js";
const PERMISSIONS = {
  // Route Access Permissions
  canAccessAdminPortal: (role) => role === "ADMIN",
  canAccessClientPortal: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  // Data Modification Permissions
  canModifyAccounts: (role) => ["ADMIN", "CLIENT"].includes(role),
  canModifyDevices: (role) => role === "ADMIN",
  canModifyAutomation: (role) => ["ADMIN", "CLIENT"].includes(role),
  canModifyScraping: (role) => ["ADMIN", "CLIENT"].includes(role),
  // View Permissions
  canViewAccounts: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  canViewDevices: (role) => role === "ADMIN",
  canViewAutomation: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  canViewScraping: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  canViewAnalytics: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  // Administrative Permissions
  canManageUsers: (role) => role === "ADMIN",
  canManageSystem: (role) => role === "ADMIN",
  canExportData: (role) => ["ADMIN", "CLIENT"].includes(role),
  canImportData: (role) => ["ADMIN", "CLIENT"].includes(role),
  // Bulk Operations
  canPerformBulkOperations: (role) => ["ADMIN", "CLIENT"].includes(role),
  // Chat/AI Features
  canUseChatbot: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  // Account Ownership Permissions
  canViewOwnAccounts: (role) => ["ADMIN", "CLIENT", "VIEWER"].includes(role),
  canViewMLAccounts: (role) => role === "ADMIN",
  canViewAllAccounts: (role) => role === "ADMIN",
  canManageAccountOwnership: (role) => role === "ADMIN",
  canAssignAccounts: (role) => role === "ADMIN",
  canViewUnassignedAccounts: (role) => role === "ADMIN"
};
const userCan = {
  accessAdminPortal: (user) => user ? PERMISSIONS.canAccessAdminPortal(user.role) : false,
  accessClientPortal: (user) => user ? PERMISSIONS.canAccessClientPortal(user.role) : false,
  modifyAccounts: (user) => user ? PERMISSIONS.canModifyAccounts(user.role) : false,
  modifyDevices: (user) => user ? PERMISSIONS.canModifyDevices(user.role) : false,
  modifyAutomation: (user) => user ? PERMISSIONS.canModifyAutomation(user.role) : false,
  modifyScraping: (user) => user ? PERMISSIONS.canModifyScraping(user.role) : false,
  viewAccounts: (user) => user ? PERMISSIONS.canViewAccounts(user.role) : false,
  viewDevices: (user) => user ? PERMISSIONS.canViewDevices(user.role) : false,
  viewAutomation: (user) => user ? PERMISSIONS.canViewAutomation(user.role) : false,
  viewScraping: (user) => user ? PERMISSIONS.canViewScraping(user.role) : false,
  viewAnalytics: (user) => user ? PERMISSIONS.canViewAnalytics(user.role) : false,
  manageUsers: (user) => user ? PERMISSIONS.canManageUsers(user.role) : false,
  manageSystem: (user) => user ? PERMISSIONS.canManageSystem(user.role) : false,
  exportData: (user) => user ? PERMISSIONS.canExportData(user.role) : false,
  importData: (user) => user ? PERMISSIONS.canImportData(user.role) : false,
  performBulkOperations: (user) => user ? PERMISSIONS.canPerformBulkOperations(user.role) : false,
  useChatbot: (user) => user ? PERMISSIONS.canUseChatbot(user.role) : false,
  // Account Ownership Helper Functions
  viewOwnAccounts: (user) => user ? PERMISSIONS.canViewOwnAccounts(user.role) : false,
  viewMLAccounts: (user) => user ? PERMISSIONS.canViewMLAccounts(user.role) : false,
  viewAllAccounts: (user) => user ? PERMISSIONS.canViewAllAccounts(user.role) : false,
  manageAccountOwnership: (user) => user ? PERMISSIONS.canManageAccountOwnership(user.role) : false,
  assignAccounts: (user) => user ? PERMISSIONS.canAssignAccounts(user.role) : false,
  viewUnassignedAccounts: (user) => user ? PERMISSIONS.canViewUnassignedAccounts(user.role) : false
};
const ADMIN_ONLY_ROUTES = ["/accounts", "/devices", "/scraping", "/settings"];
const CLIENT_PORTAL_ROUTES = ["/client-portal"];
const UNAUTHORIZED_ROUTES = ["/access-pending"];
const AUTH_ROUTES = ["/login", "/register", "/forgot-password", "/reset-password", "/api/auth", "/api/test-login"];
const PUBLIC_ROUTES = ["/unauthorized"];
const rateLimitHandle = async ({ event, resolve }) => {
  const pathname = event.url.pathname;
  const isBasicPageLoad = pathname === "/" || pathname === "/login" || pathname.startsWith("/client-portal");
  if (!isBasicPageLoad && (pathname.startsWith("/api/") || event.request.method !== "GET")) {
    const rateLimitResponse = await rateLimitMiddleware(event);
    if (rateLimitResponse) {
      return rateLimitResponse;
    }
  }
  return resolve(event);
};
const authSessionHandle = async ({ event, resolve }) => {
  const { cookies, url } = event;
  if (event.locals.auth) {
    try {
      const authSession = await event.locals.auth();
      if (authSession?.user?.email) {
        const sessionUser = {
          id: authSession.user.id || `oauth_${authSession.user.email}`,
          email: authSession.user.email,
          name: authSession.user.name || authSession.user.email,
          role: authSession.user.role || "CLIENT",
          // Use role from Auth.js token or default to CLIENT
          isActive: true,
          company: authSession.user.company || null,
          avatar: authSession.user.image || null,
          subscription: authSession.user.subscription || "Basic",
          lastLoginAt: /* @__PURE__ */ new Date()
        };
        event.locals.user = sessionUser;
        console.log(`🔐 Auth.js session found for: ${authSession.user.email} (role: ${sessionUser.role})`);
      }
    } catch (error) {
      console.error("Error checking Auth.js session:", error);
    }
  }
  const oldSessionCookie = cookies.get("session");
  if (oldSessionCookie) {
    console.log("🧹 Cleaning up old session cookie");
    cookies.delete("session", { path: "/", secure: !dev, httpOnly: true, sameSite: "lax" });
  }
  const pathname = url.pathname;
  const isAuthRoute = AUTH_ROUTES.some((route) => pathname.startsWith(route));
  const isPublicRoute = PUBLIC_ROUTES.some((route) => pathname.startsWith(route));
  const isUnauthorizedRoute = UNAUTHORIZED_ROUTES.some((route) => pathname.startsWith(route));
  const isOAuthRoute = pathname.startsWith("/auth/") || pathname.startsWith("/api/auth/oauth/");
  const isApiRoute = pathname.startsWith("/api/");
  const isAdminRoute = ADMIN_ONLY_ROUTES.some((route) => pathname.startsWith(route));
  const isClientPortalRoute = CLIENT_PORTAL_ROUTES.some((route) => pathname.startsWith(route));
  if (isOAuthRoute || isPublicRoute || isUnauthorizedRoute) {
    return resolve(event);
  }
  if (!event.locals.user) {
    if (isAuthRoute) {
      return resolve(event);
    }
    const redirectUrl = `/login?redirectTo=${encodeURIComponent(pathname)}`;
    throw redirect(302, redirectUrl);
  }
  if (isAuthRoute && event.locals.user) {
    if (userCan.accessClientPortal(event.locals.user) || userCan.accessAdminPortal(event.locals.user)) {
      throw redirect(302, "/client-portal");
    } else if (event.locals.user.role === "UNAUTHORIZED") {
      throw redirect(302, "/access-pending");
    }
    throw redirect(302, "/login");
  }
  if (!event.locals.user) {
    return resolve(event);
  }
  const userRole = event.locals.user.role;
  if (userRole === "UNAUTHORIZED" && !isUnauthorizedRoute) {
    throw redirect(302, "/access-pending");
  }
  if (isAdminRoute && !userCan.accessAdminPortal(event.locals.user)) {
    const isProfilePage = pathname.startsWith("/scraping/profile/");
    if (isProfilePage && (userRole === "CLIENT" || userRole === "VIEWER")) ;
    else {
      throw redirect(302, `/unauthorized?from=${encodeURIComponent(pathname)}`);
    }
  }
  if (isClientPortalRoute && !userCan.accessClientPortal(event.locals.user)) {
    throw redirect(302, `/unauthorized?from=${encodeURIComponent(pathname)}`);
  }
  if (isApiRoute) {
    const method = event.request.method;
    const apiPath = pathname;
    if (userRole === "UNAUTHORIZED") {
      return new Response(
        JSON.stringify({
          error: "Access pending: Your account requires administrator approval",
          code: "ACCESS_PENDING"
        }),
        {
          status: 403,
          headers: { "Content-Type": "application/json" }
        }
      );
    }
    if (["POST", "PUT", "DELETE"].includes(method)) {
      if (userRole === "VIEWER") {
        return new Response(
          JSON.stringify({
            error: "Forbidden: Viewers cannot perform modification operations",
            code: "INSUFFICIENT_PERMISSIONS"
          }),
          {
            status: 403,
            headers: { "Content-Type": "application/json" }
          }
        );
      }
      if (apiPath.startsWith("/api/devices") && userRole !== "ADMIN") {
        return new Response(
          JSON.stringify({
            error: "Forbidden: Only administrators can manage devices",
            code: "ADMIN_REQUIRED"
          }),
          {
            status: 403,
            headers: { "Content-Type": "application/json" }
          }
        );
      }
    }
    if (apiPath.startsWith("/api/devices") && userRole !== "ADMIN") {
      return new Response(
        JSON.stringify({
          error: "Forbidden: Only administrators can access device information",
          code: "ADMIN_REQUIRED"
        }),
        {
          status: 403,
          headers: { "Content-Type": "application/json" }
        }
      );
    }
  }
  return resolve(event);
};
const handleError = async ({ error, event, status, message }) => {
  const errorId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const userId = event.locals.user?.id;
  const requestId = event.locals.requestId;
  const ip = event.getClientAddress();
  const userAgent = event.request.headers.get("user-agent");
  logger.logSystem(LogLevel.ERROR, `Server error: ${message}`, {
    component: "server-error-handler",
    event: "server_error",
    details: {
      errorId,
      status,
      message,
      url: event.url.pathname,
      method: event.request.method,
      userId,
      requestId,
      ip,
      userAgent,
      stack: error instanceof Error ? error.stack : void 0
    },
    error: error instanceof Error ? error : void 0
  });
  if (status >= 500) {
    logger.logSecurity(LogLevel.ERROR, `Critical server error: ${message}`, {
      eventType: "server_error",
      severity: "high",
      userId,
      ip,
      userAgent,
      details: {
        errorId,
        status,
        url: event.url.pathname,
        method: event.request.method
      }
    });
  }
  return {
    id: errorId,
    message,
    ...error instanceof Error && { stack: error.stack }
  };
};
const handle = sequence(
  rateLimitHandle,
  authHandle,
  authSessionHandle
);
export {
  handle,
  handleError
};
