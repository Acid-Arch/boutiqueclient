import{c as d,l as i}from"./CgY5D-bl.js";import"./BRn0EAu4.js";import{p,a as m,w as u,c as f,f as $,b as _,d as g,F as v}from"./dabN1jmf.js";import{I as h,s as y}from"./ChEOsMF6.js";import{l as I,s as N}from"./D0VStH_y.js";s[v]="node_modules/lucide-svelte/dist/icons/clock.svelte";function s(o,e){d(new.target);const n=I(e,["children","$$slots","$$events","$$legacy"]);p(e,!1,s);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["path",{d:"M12 6v6l4 2"}],["circle",{cx:"12",cy:"12",r:"10"}]];return m(()=>h(o,N({name:"clock"},()=>n,{get iconNode(){return c},children:u(s,(l,b)=>{var t=f(),r=$(t);y(r,e,"default",{},null),_(l,t)}),$$slots:{default:!0}})),"component",s,36,0,{componentTag:"Icon"}),g({...i()})}a[v]="node_modules/lucide-svelte/dist/icons/database.svelte";function a(o,e){d(new.target);const n=I(e,["children","$$slots","$$events","$$legacy"]);p(e,!1,a);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const c=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5"}],["path",{d:"M3 12A9 3 0 0 0 21 12"}]];return m(()=>h(o,N({name:"database"},()=>n,{get iconNode(){return c},children:u(a,(l,b)=>{var t=f(),r=$(t);y(r,e,"default",{},null),_(l,t)}),$$slots:{default:!0}})),"component",a,36,0,{componentTag:"Icon"}),g({...i()})}export{s as C,a as D};
