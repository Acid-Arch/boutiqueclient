-- CreateEnum
CREATE TYPE "ScrapingStatus" AS ENUM ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'RATE_LIMITED', 'ACCOUNT_PRIVATE', 'ACCOUNT_NOT_FOUND', 'INSUFFICIENT_BALANCE', 'CANCELLED');

-- CreateEnum
CREATE TYPE "ScrapingSessionType" AS ENUM ('ACCOUNT_METRICS', 'FOLLOWER_ANALYSIS', 'CONTENT_ANALYSIS', 'COMPETITOR_ANALYSIS', 'HASHTAG_RESEARCH', 'TREND_ANALYSIS', 'BULK_UPDATE', 'HEALTH_CHECK');

-- CreateEnum
CREATE TYPE "ScrapingSessionStatus" AS ENUM ('PENDING', 'INITIALIZING', 'RUNNING', 'PAUSED', 'COMPLETED', 'FAILED', 'CANCELLED', 'RATE_LIMITED');

-- CreateEnum
CREATE TYPE "ScrapingSource" AS ENUM ('HIKER_API_CLIENT', 'ACCOUNT_SCRAPER', 'FOLLOWER_SCRAPER', 'CONTENT_SCRAPER', 'RATE_LIMITER', 'SESSION_MANAGER', 'DATA_VALIDATOR', 'COST_MONITOR');

-- CreateEnum
CREATE TYPE "ScrapingStep" AS ENUM ('INIT_SESSION', 'VALIDATE_ACCOUNT', 'FETCH_PROFILE', 'FETCH_FOLLOWERS', 'FETCH_FOLLOWING', 'FETCH_MEDIA', 'FETCH_STORIES', 'FETCH_HIGHLIGHTS', 'CALCULATE_METRICS', 'VALIDATE_DATA', 'STORE_RESULTS', 'CLEANUP');

-- CreateEnum
CREATE TYPE "ScrapingErrorType" AS ENUM ('RATE_LIMIT_EXCEEDED', 'INSUFFICIENT_BALANCE', 'ACCOUNT_NOT_FOUND', 'ACCOUNT_PRIVATE', 'NETWORK_ERROR', 'TIMEOUT_ERROR', 'AUTHENTICATION_ERROR', 'DATA_VALIDATION_ERROR', 'DATABASE_ERROR', 'UNKNOWN_ERROR');

-- CreateEnum
CREATE TYPE "TriggerSource" AS ENUM ('MANUAL', 'SCHEDULED', 'API', 'WEBHOOK');

-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'CLIENT', 'VIEWER', 'UNAUTHORIZED');

-- CreateEnum
CREATE TYPE "AccountType" AS ENUM ('CLIENT', 'ML_TREND_FINDER', 'SYSTEM');

-- CreateEnum
CREATE TYPE "AccountVisibility" AS ENUM ('PRIVATE', 'SHARED', 'PUBLIC');

-- CreateEnum
CREATE TYPE "AuditEventType" AS ENUM ('LOGIN_SUCCESS', 'LOGIN_FAILURE', 'LOGIN_BLOCKED_RATE_LIMIT', 'PASSWORD_RESET_REQUEST', 'PASSWORD_RESET_COMPLETE', 'PASSWORD_CHANGE', 'SESSION_INVALIDATED', 'TWO_FACTOR_ENABLED', 'TWO_FACTOR_DISABLED', 'ACCOUNT_LOCKED', 'ACCOUNT_UNLOCKED');

-- CreateTable
CREATE TABLE "ig_accounts" (
    "id" SERIAL NOT NULL,
    "record_id" VARCHAR(255),
    "instagram_username" VARCHAR(255) NOT NULL,
    "instagram_password" VARCHAR(255) NOT NULL,
    "email_address" VARCHAR(255) NOT NULL,
    "email_password" VARCHAR(255) NOT NULL,
    "status" VARCHAR(50) NOT NULL DEFAULT 'Unused',
    "imap_status" VARCHAR(10) NOT NULL DEFAULT 'On',
    "assigned_device_id" VARCHAR(255),
    "assigned_clone_number" INTEGER,
    "assigned_package_name" VARCHAR(255),
    "assignment_timestamp" TIMESTAMP(3),
    "login_timestamp" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ownerId" INTEGER,
    "accountType" "AccountType" NOT NULL DEFAULT 'CLIENT',
    "visibility" "AccountVisibility" NOT NULL DEFAULT 'PRIVATE',
    "is_shared" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "ig_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "clone_inventory" (
    "id" SERIAL NOT NULL,
    "device_id" VARCHAR(255) NOT NULL,
    "clone_number" INTEGER NOT NULL,
    "package_name" VARCHAR(255) NOT NULL,
    "clone_status" VARCHAR(50) NOT NULL DEFAULT 'Available',
    "current_account" VARCHAR(255),
    "device_name" VARCHAR(255),
    "clone_health" VARCHAR(50),
    "last_scanned" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "clone_inventory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "warmup_accounts" (
    "id" SERIAL NOT NULL,
    "record_id" VARCHAR(255),
    "instagram_username" VARCHAR(255) NOT NULL,
    "package_name" VARCHAR(255) NOT NULL,
    "assigned_device_id" VARCHAR(255),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "warmup_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" SERIAL NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "username" VARCHAR(100) NOT NULL,
    "password_hash" VARCHAR(255),
    "first_name" VARCHAR(100),
    "last_name" VARCHAR(100),
    "company" VARCHAR(255),
    "avatar" VARCHAR(500),
    "role" "UserRole" NOT NULL DEFAULT 'CLIENT',
    "subscription" VARCHAR(50) NOT NULL DEFAULT 'Basic',
    "accounts_limit" INTEGER NOT NULL DEFAULT 10,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "is_verified" BOOLEAN NOT NULL DEFAULT false,
    "email_verified" BOOLEAN NOT NULL DEFAULT false,
    "is_two_factor_enabled" BOOLEAN NOT NULL DEFAULT false,
    "two_factor_enabled" BOOLEAN NOT NULL DEFAULT false,
    "two_factor_secret" VARCHAR(255),
    "backup_codes" JSONB,
    "last_login_at" TIMESTAMP(3),
    "last_active_at" TIMESTAMP(3),
    "login_attempts" INTEGER NOT NULL DEFAULT 0,
    "locked_until" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_preferences" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "preference_key" VARCHAR(100) NOT NULL,
    "preference_value" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_preferences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "login_attempts" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER,
    "email" VARCHAR(255) NOT NULL,
    "ip_address" VARCHAR(45) NOT NULL,
    "user_agent" TEXT,
    "success" BOOLEAN NOT NULL DEFAULT false,
    "failure_reason" VARCHAR(255),
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "login_attempts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "password_reset_tokens" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "token" VARCHAR(255) NOT NULL,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "used" BOOLEAN NOT NULL DEFAULT false,
    "ip_address" VARCHAR(45) NOT NULL,
    "user_agent" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "used_at" TIMESTAMP(3),

    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_sessions" (
    "id" TEXT NOT NULL,
    "user_id" INTEGER NOT NULL,
    "session_token" VARCHAR(255) NOT NULL,
    "ip_address" VARCHAR(45) NOT NULL,
    "user_agent" TEXT,
    "device_info" JSONB,
    "last_activity" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expires_at" TIMESTAMP(3) NOT NULL,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "remember_me" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL,
    "user_id" INTEGER,
    "event_type" "AuditEventType" NOT NULL,
    "description" TEXT,
    "details" JSONB,
    "ip_address" VARCHAR(45),
    "user_agent" TEXT,
    "success" BOOLEAN NOT NULL DEFAULT true,
    "error_message" TEXT,
    "metadata" JSONB,
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "accounts" (
    "id" TEXT NOT NULL,
    "user_id" INTEGER NOT NULL,
    "type" TEXT NOT NULL,
    "provider" TEXT NOT NULL,
    "provider_account_id" TEXT NOT NULL,
    "refresh_token" TEXT,
    "access_token" TEXT,
    "expires_at" INTEGER,
    "token_type" TEXT,
    "scope" TEXT,
    "id_token" TEXT,
    "session_state" TEXT,

    CONSTRAINT "accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sessions" (
    "id" TEXT NOT NULL,
    "session_token" TEXT NOT NULL,
    "user_id" INTEGER NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "verification_tokens" (
    "identifier" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expires" TIMESTAMP(3) NOT NULL
);

-- CreateTable
CREATE TABLE "scraping_sessions" (
    "id" TEXT NOT NULL,
    "session_type" "ScrapingSessionType" NOT NULL,
    "status" "ScrapingSessionStatus" NOT NULL DEFAULT 'PENDING',
    "total_accounts" INTEGER NOT NULL DEFAULT 0,
    "completed_accounts" INTEGER NOT NULL DEFAULT 0,
    "failed_accounts" INTEGER NOT NULL DEFAULT 0,
    "skipped_accounts" INTEGER NOT NULL DEFAULT 0,
    "progress" INTEGER NOT NULL DEFAULT 0,
    "start_time" TIMESTAMP(3),
    "end_time" TIMESTAMP(3),
    "estimated_completion" TIMESTAMP(3),
    "total_request_units" INTEGER NOT NULL DEFAULT 0,
    "estimated_cost" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "error_count" INTEGER NOT NULL DEFAULT 0,
    "last_error" TEXT,
    "triggered_by" TEXT,
    "trigger_source" TEXT NOT NULL DEFAULT 'MANUAL',
    "target_usernames" JSONB,
    "scraping_config" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "scraping_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ig_accounts_record_id_key" ON "ig_accounts"("record_id");

-- CreateIndex
CREATE UNIQUE INDEX "ig_accounts_instagram_username_key" ON "ig_accounts"("instagram_username");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_assigned_device" ON "ig_accounts"("assigned_device_id");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_imap_status" ON "ig_accounts"("imap_status");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_status" ON "ig_accounts"("status");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_username" ON "ig_accounts"("instagram_username");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_owner_id" ON "ig_accounts"("ownerId");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_account_type" ON "ig_accounts"("accountType");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_visibility" ON "ig_accounts"("visibility");

-- CreateIndex
CREATE INDEX "idx_ig_accounts_owner_type" ON "ig_accounts"("ownerId", "accountType");

-- CreateIndex
CREATE UNIQUE INDEX "clone_inventory_device_id_clone_number_key" ON "clone_inventory"("device_id", "clone_number");

-- CreateIndex
CREATE INDEX "idx_clone_inventory_device" ON "clone_inventory"("device_id");

-- CreateIndex
CREATE INDEX "idx_clone_inventory_device_clone" ON "clone_inventory"("device_id", "clone_number");

-- CreateIndex
CREATE INDEX "idx_clone_inventory_status" ON "clone_inventory"("clone_status");

-- CreateIndex
CREATE UNIQUE INDEX "warmup_accounts_record_id_key" ON "warmup_accounts"("record_id");

-- CreateIndex
CREATE INDEX "idx_warmup_accounts_device" ON "warmup_accounts"("assigned_device_id");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE INDEX "idx_users_email" ON "users"("email");

-- CreateIndex
CREATE INDEX "idx_users_username" ON "users"("username");

-- CreateIndex
CREATE INDEX "idx_users_role" ON "users"("role");

-- CreateIndex
CREATE INDEX "idx_users_active" ON "users"("is_active");

-- CreateIndex
CREATE INDEX "idx_users_last_login" ON "users"("last_login_at");

-- CreateIndex
CREATE INDEX "idx_users_created" ON "users"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "user_preferences_user_id_preference_key_key" ON "user_preferences"("user_id", "preference_key");

-- CreateIndex
CREATE INDEX "idx_user_preferences_user_id" ON "user_preferences"("user_id");

-- CreateIndex
CREATE INDEX "idx_user_preferences_key" ON "user_preferences"("preference_key");

-- CreateIndex
CREATE INDEX "idx_login_attempts_email" ON "login_attempts"("email");

-- CreateIndex
CREATE INDEX "idx_login_attempts_ip" ON "login_attempts"("ip_address");

-- CreateIndex
CREATE INDEX "idx_login_attempts_timestamp" ON "login_attempts"("timestamp");

-- CreateIndex
CREATE INDEX "idx_login_attempts_success" ON "login_attempts"("success");

-- CreateIndex
CREATE UNIQUE INDEX "password_reset_tokens_token_key" ON "password_reset_tokens"("token");

-- CreateIndex
CREATE INDEX "idx_password_reset_tokens_user" ON "password_reset_tokens"("user_id");

-- CreateIndex
CREATE INDEX "idx_password_reset_tokens_token" ON "password_reset_tokens"("token");

-- CreateIndex
CREATE INDEX "idx_password_reset_tokens_expires" ON "password_reset_tokens"("expires_at");

-- CreateIndex
CREATE UNIQUE INDEX "user_sessions_session_token_key" ON "user_sessions"("session_token");

-- CreateIndex
CREATE INDEX "idx_user_sessions_user" ON "user_sessions"("user_id");

-- CreateIndex
CREATE INDEX "idx_user_sessions_token" ON "user_sessions"("session_token");

-- CreateIndex
CREATE INDEX "idx_user_sessions_activity" ON "user_sessions"("last_activity");

-- CreateIndex
CREATE INDEX "idx_user_sessions_expires" ON "user_sessions"("expires_at");

-- CreateIndex
CREATE INDEX "idx_user_sessions_active" ON "user_sessions"("active");

-- CreateIndex
CREATE INDEX "idx_audit_logs_user_id" ON "audit_logs"("user_id");

-- CreateIndex
CREATE INDEX "idx_audit_logs_event_type" ON "audit_logs"("event_type");

-- CreateIndex
CREATE INDEX "idx_audit_logs_timestamp" ON "audit_logs"("timestamp");

-- CreateIndex
CREATE INDEX "idx_audit_logs_ip_address" ON "audit_logs"("ip_address");

-- CreateIndex
CREATE INDEX "idx_audit_logs_success" ON "audit_logs"("success");

-- CreateIndex
CREATE UNIQUE INDEX "accounts_provider_provider_account_id_key" ON "accounts"("provider", "provider_account_id");

-- CreateIndex
CREATE UNIQUE INDEX "sessions_session_token_key" ON "sessions"("session_token");

-- CreateIndex
CREATE UNIQUE INDEX "verification_tokens_token_key" ON "verification_tokens"("token");

-- CreateIndex
CREATE UNIQUE INDEX "verification_tokens_identifier_token_key" ON "verification_tokens"("identifier", "token");

-- CreateIndex
CREATE INDEX "idx_scraping_sessions_status" ON "scraping_sessions"("status");

-- CreateIndex
CREATE INDEX "idx_scraping_sessions_type" ON "scraping_sessions"("session_type");

-- CreateIndex
CREATE INDEX "idx_scraping_sessions_created" ON "scraping_sessions"("created_at");

-- CreateIndex
CREATE INDEX "idx_scraping_sessions_trigger" ON "scraping_sessions"("trigger_source");

-- AddForeignKey
ALTER TABLE "ig_accounts" ADD CONSTRAINT "ig_accounts_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_preferences" ADD CONSTRAINT "user_preferences_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "login_attempts" ADD CONSTRAINT "login_attempts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "password_reset_tokens" ADD CONSTRAINT "password_reset_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_sessions" ADD CONSTRAINT "user_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "accounts" ADD CONSTRAINT "accounts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;