import { p as push, h as head, g as push_element, k as escape_html, j as pop_element, l as prevent_snippet_stringification, m as bind_props, f as pop, F as FILENAME, o as ensure_array_like } from "../../../chunks/index3.js";
import { C as Card, a as Card_header, b as Card_title, c as Card_content } from "../../../chunks/card-title.js";
import "clsx";
import { B as Button, a as Badge } from "../../../chunks/badge.js";
import { P as Play, C as Circle_check_big, a as Circle_alert } from "../../../chunks/play.js";
import { A as Activity } from "../../../chunks/activity.js";
_page[FILENAME] = "src/routes/client-portal/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  let recentActivity;
  let data = $$props["data"];
  data.stats || {
    totalAccounts: 0,
    activeAccounts: 0,
    assignedDevices: 0,
    totalFollowers: 0
  };
  recentActivity = data.recentActivity || [];
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Dashboard - Client Portal</title>`;
  });
  $$payload.out.push(`<div class="space-y-6">`);
  push_element($$payload, "div", 39, 0);
  $$payload.out.push(`<div class="glass-card p-6 rounded-xl">`);
  push_element($$payload, "div", 41, 1);
  $$payload.out.push(`<div class="flex items-center justify-between">`);
  push_element($$payload, "div", 42, 2);
  $$payload.out.push(`<div>`);
  push_element($$payload, "div", 43, 3);
  $$payload.out.push(`<h1 class="text-2xl font-bold text-white mb-2">`);
  push_element($$payload, "h1", 44, 4);
  $$payload.out.push(`Welcome back, ${escape_html(data.user?.name?.split(" ")[0] || "User")}! 👋</h1>`);
  pop_element();
  $$payload.out.push(` <p class="text-slate-300">`);
  push_element($$payload, "p", 47, 4);
  $$payload.out.push(`Here's what's happening with your Instagram accounts today.</p>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` <div class="hidden md:block">`);
  push_element($$payload, "div", 51, 3);
  Button($$payload, {
    class: "bg-blue-600 hover:bg-blue-700 text-white",
    children: prevent_snippet_stringification(($$payload2) => {
      Play($$payload2, { class: "w-4 h-4 mr-2" });
      $$payload2.out.push(`<!----> Start Automation`);
    }),
    $$slots: { default: true }
  });
  $$payload.out.push(`<!----></div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` `);
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--> <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">`);
  push_element($$payload, "div", 100, 1);
  $$payload.out.push(`<div class="lg:col-span-2">`);
  push_element($$payload, "div", 102, 2);
  Card($$payload, {
    class: "glass-card border-white/10",
    children: prevent_snippet_stringification(($$payload2) => {
      Card_header($$payload2, {
        children: prevent_snippet_stringification(($$payload3) => {
          Card_title($$payload3, {
            class: "text-white flex items-center",
            children: prevent_snippet_stringification(($$payload4) => {
              Activity($$payload4, { class: "w-5 h-5 mr-2 text-blue-400" });
              $$payload4.out.push(`<!----> Recent Activity`);
            }),
            $$slots: { default: true }
          });
        }),
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----> `);
      Card_content($$payload2, {
        children: prevent_snippet_stringification(($$payload3) => {
          $$payload3.out.push(`<div class="space-y-4">`);
          push_element($$payload3, "div", 111, 5);
          if (recentActivity.length > 0) {
            $$payload3.out.push("<!--[-->");
            const each_array = ensure_array_like(recentActivity);
            $$payload3.out.push(`<!--[-->`);
            for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
              let activity = each_array[$$index];
              $$payload3.out.push(`<div class="flex items-center justify-between p-3 glass rounded-lg">`);
              push_element($$payload3, "div", 114, 8);
              $$payload3.out.push(`<div class="flex items-center space-x-3">`);
              push_element($$payload3, "div", 115, 9);
              $$payload3.out.push(`<div class="flex-shrink-0">`);
              push_element($$payload3, "div", 116, 10);
              if (activity.status === "success" || activity.status === "completed") {
                $$payload3.out.push("<!--[-->");
                Circle_check_big($$payload3, { class: "w-5 h-5 text-green-400" });
              } else {
                $$payload3.out.push("<!--[!-->");
                Circle_alert($$payload3, { class: "w-5 h-5 text-yellow-400" });
              }
              $$payload3.out.push(`<!--]--></div>`);
              pop_element();
              $$payload3.out.push(` <div>`);
              push_element($$payload3, "div", 123, 10);
              $$payload3.out.push(`<p class="text-sm font-medium text-white">`);
              push_element($$payload3, "p", 124, 11);
              if (activity.type === "accountlogin") {
                $$payload3.out.push("<!--[-->");
                $$payload3.out.push(`Account login: <span class="text-blue-300">`);
                push_element($$payload3, "span", 126, 28);
                $$payload3.out.push(`${escape_html(activity.account)}</span>`);
                pop_element();
              } else {
                $$payload3.out.push("<!--[!-->");
                if (activity.type === "deviceassignment") {
                  $$payload3.out.push("<!--[-->");
                  $$payload3.out.push(`Device assigned: <span class="text-slate-300">`);
                  push_element($$payload3, "span", 128, 30);
                  $$payload3.out.push(`${escape_html(activity.device || "Device")}</span>`);
                  pop_element();
                  $$payload3.out.push(` → <span class="text-blue-300">`);
                  push_element($$payload3, "span", 128, 98);
                  $$payload3.out.push(`${escape_html(activity.account)}</span>`);
                  pop_element();
                } else {
                  $$payload3.out.push("<!--[!-->");
                  if (activity.type === "scrapingsession") {
                    $$payload3.out.push("<!--[-->");
                    $$payload3.out.push(`Scraping completed: <span class="text-blue-300">`);
                    push_element($$payload3, "span", 130, 33);
                    $$payload3.out.push(`${escape_html(activity.account)}</span>`);
                    pop_element();
                  } else {
                    $$payload3.out.push("<!--[!-->");
                    if (activity.type === "userlogin") {
                      $$payload3.out.push("<!--[-->");
                      $$payload3.out.push(`User login: <span class="text-blue-300">`);
                      push_element($$payload3, "span", 132, 25);
                      $$payload3.out.push(`${escape_html(activity.account)}</span>`);
                      pop_element();
                    } else {
                      $$payload3.out.push("<!--[!-->");
                      $$payload3.out.push(`Activity: <span class="text-blue-300">`);
                      push_element($$payload3, "span", 134, 23);
                      $$payload3.out.push(`${escape_html(activity.type)}</span>`);
                      pop_element();
                    }
                    $$payload3.out.push(`<!--]-->`);
                  }
                  $$payload3.out.push(`<!--]-->`);
                }
                $$payload3.out.push(`<!--]-->`);
              }
              $$payload3.out.push(`<!--]--></p>`);
              pop_element();
              $$payload3.out.push(` <p class="text-xs text-slate-400">`);
              push_element($$payload3, "p", 137, 11);
              $$payload3.out.push(`${escape_html(activity.time)}</p>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` `);
              Badge($$payload3, {
                variant: "outline",
                class: activity.status === "success" || activity.status === "completed" ? "border-green-500 text-green-400" : activity.status === "error" ? "border-red-500 text-red-400" : "border-yellow-500 text-yellow-400",
                children: prevent_snippet_stringification(($$payload4) => {
                  $$payload4.out.push(`<!---->${escape_html(activity.status)}`);
                }),
                $$slots: { default: true }
              });
              $$payload3.out.push(`<!----></div>`);
              pop_element();
            }
            $$payload3.out.push(`<!--]-->`);
          } else {
            $$payload3.out.push("<!--[!-->");
            $$payload3.out.push(`<div class="text-center py-8">`);
            push_element($$payload3, "div", 155, 7);
            Activity($$payload3, { class: "w-12 h-12 mx-auto text-slate-500 mb-4" });
            $$payload3.out.push(`<!----> <p class="text-slate-400 text-sm">`);
            push_element($$payload3, "p", 157, 8);
            $$payload3.out.push(`No recent activity found</p>`);
            pop_element();
            $$payload3.out.push(` <p class="text-slate-500 text-xs mt-1">`);
            push_element($$payload3, "p", 158, 8);
            $$payload3.out.push(`Account activities will appear here when available</p>`);
            pop_element();
            $$payload3.out.push(`</div>`);
            pop_element();
          }
          $$payload3.out.push(`<!--]--></div>`);
          pop_element();
        }),
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!---->`);
    }),
    $$slots: { default: true }
  });
  $$payload.out.push(`<!----></div>`);
  pop_element();
  $$payload.out.push(` <div>`);
  push_element($$payload, "div", 167, 2);
  Card($$payload, {
    class: "glass-card border-white/10",
    children: prevent_snippet_stringification(($$payload2) => {
      Card_header($$payload2, {
        children: prevent_snippet_stringification(($$payload3) => {
          Card_title($$payload3, {
            class: "text-white text-sm",
            children: prevent_snippet_stringification(($$payload4) => {
              $$payload4.out.push(`<!---->Account Status`);
            }),
            $$slots: { default: true }
          });
        }),
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!----> `);
      Card_content($$payload2, {
        class: "space-y-3",
        children: prevent_snippet_stringification(($$payload3) => {
          $$payload3.out.push(`<div class="flex items-center justify-between">`);
          push_element($$payload3, "div", 173, 5);
          $$payload3.out.push(`<span class="text-sm text-slate-300">`);
          push_element($$payload3, "span", 174, 6);
          $$payload3.out.push(`Subscription</span>`);
          pop_element();
          $$payload3.out.push(` `);
          Badge($$payload3, {
            class: "bg-blue-500/20 text-blue-300",
            children: prevent_snippet_stringification(($$payload4) => {
              $$payload4.out.push(`<!---->${escape_html(data.user?.subscription || "Basic")}`);
            }),
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div>`);
          pop_element();
          $$payload3.out.push(` <div class="flex items-center justify-between">`);
          push_element($$payload3, "div", 177, 5);
          $$payload3.out.push(`<span class="text-sm text-slate-300">`);
          push_element($$payload3, "span", 178, 6);
          $$payload3.out.push(`Account Limit</span>`);
          pop_element();
          $$payload3.out.push(` <span class="text-sm text-white">`);
          push_element($$payload3, "span", 179, 6);
          $$payload3.out.push(`${escape_html(data.stats?.totalAccounts || 0)} / ${escape_html(data.user?.accountsLimit || 10)}</span>`);
          pop_element();
          $$payload3.out.push(`</div>`);
          pop_element();
          $$payload3.out.push(` <div class="flex items-center justify-between">`);
          push_element($$payload3, "div", 181, 5);
          $$payload3.out.push(`<span class="text-sm text-slate-300">`);
          push_element($$payload3, "span", 182, 6);
          $$payload3.out.push(`Status</span>`);
          pop_element();
          $$payload3.out.push(` `);
          Badge($$payload3, {
            class: "bg-green-500/20 text-green-300",
            children: prevent_snippet_stringification(($$payload4) => {
              $$payload4.out.push(`<!---->${escape_html(data.user?.isActive ? "Active" : "Inactive")}`);
            }),
            $$slots: { default: true }
          });
          $$payload3.out.push(`<!----></div>`);
          pop_element();
        }),
        $$slots: { default: true }
      });
      $$payload2.out.push(`<!---->`);
    }),
    $$slots: { default: true }
  });
  $$payload.out.push(`<!----></div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  bind_props($$props, { data });
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
