import"./DsnmJJEf.js";import{i as S}from"./DX-Oc8op.js";import{z as B,E as I,p as q,ah as A,u as b,q as d,a as w,b as E,e as O,c as P,f as $,g,ai as D,i as F,r as G,aj as H}from"./3zx2OM-S.js";import{e as J,i as K}from"./z8oQ6GeD.js";import{b as y,e as L}from"./lPcixCUF.js";import{l as z,p as n}from"./Dwjkgfq3.js";function M(s,e,t,u,i){B&&I();var a=e.$$slots?.[t],r=!1;a===!0&&(a=e[t==="default"?"children":t],r=!0),a===void 0?i!==null&&i(s):a(s,r?()=>u:u)}function te(s){const e={};s.children&&(e.default=!0);for(const t in s.$$slots)e[t]=!0;return e}/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const Q={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var R=A("<svg><!><!></svg>");function se(s,e){const t=z(e,["children","$$slots","$$events","$$legacy"]),u=z(t,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);q(e,!1);let i=n(e,"name",8,void 0),a=n(e,"color",8,"currentColor"),r=n(e,"size",8,24),h=n(e,"strokeWidth",8,2),v=n(e,"absoluteStrokeWidth",8,!1),x=n(e,"iconNode",24,()=>[]);const W=(...l)=>l.filter((o,f,m)=>!!o&&m.indexOf(o)===f).join(" ");S();var c=R();y(c,(l,o)=>({...Q,...u,width:r(),height:r(),stroke:a(),"stroke-width":l,class:o}),[()=>(d(v()),d(h()),d(r()),b(()=>v()?Number(h())*24/Number(r()):h())),()=>(d(i()),d(t),b(()=>W("lucide-icon","lucide",i()?`lucide-${i()}`:"",t.class)))]);var _=O(c);J(_,1,x,K,(l,o)=>{var f=D(()=>H(g(o),2));let m=()=>g(f)[0],j=()=>g(f)[1];var k=P(),p=$(k);L(p,m,!0,(C,T)=>{y(C,()=>({...j()}))}),w(l,k)});var N=F(_);M(N,e,"default",{},null),G(c),w(s,c),E()}export{se as I,te as a,M as s};
