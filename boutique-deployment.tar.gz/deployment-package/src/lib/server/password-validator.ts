export interface PasswordValidationResult {
	isValid: boolean;
	errors: string[];
	strength: 'very-weak' | 'weak' | 'fair' | 'good' | 'strong';
	score: number;
}

export interface PasswordRequirement {
	name: string;
	test: (password: string) => boolean;
	message: string;
}

const requirements: PasswordRequirement[] = [
	{
		name: 'length',
		test: (pwd) => pwd.length >= 8,
		message: 'Password must be at least 8 characters long'
	},
	{
		name: 'uppercase',
		test: (pwd) => /[A-Z]/.test(pwd),
		message: 'Password must contain at least one uppercase letter'
	},
	{
		name: 'lowercase',
		test: (pwd) => /[a-z]/.test(pwd),
		message: 'Password must contain at least one lowercase letter'
	},
	{
		name: 'number',
		test: (pwd) => /\d/.test(pwd),
		message: 'Password must contain at least one number'
	},
	{
		name: 'special',
		test: (pwd) => /[!@#$%^&*(),.?":{}|<>]/.test(pwd),
		message: 'Password must contain at least one special character'
	}
];

// Common weak passwords (subset for demonstration)
const commonPasswords = new Set([
	'password', '123456', '123456789', 'qwerty', 'abc123', 'password123',
	'admin', 'letmein', 'welcome', 'monkey', '1234567890', 'iloveyou',
	'princess', 'rockyou', '12345678', 'qwerty123', 'password1'
]);

export class PasswordValidator {
	/**
	 * Validate password against all requirements
	 */
	static validate(password: string): PasswordValidationResult {
		const errors: string[] = [];
		let score = 0;

		// Check each requirement
		for (const req of requirements) {
			if (req.test(password)) {
				score++;
			} else {
				errors.push(req.message);
			}
		}

		// Additional scoring factors
		if (password.length >= 12) score += 0.5;
		if (password.length >= 16) score += 0.5;
		if (!/(.)\1{2,}/.test(password)) score += 0.5; // No repeating characters
		if (!commonPasswords.has(password.toLowerCase())) score += 0.5;

		// Check for common weak patterns
		if (this.hasCommonPattern(password)) {
			errors.push('Password contains common patterns that are easy to guess');
			score -= 1;
		}

		// Check against common passwords
		if (commonPasswords.has(password.toLowerCase())) {
			errors.push('This password is commonly used and not secure');
			score -= 1;
		}

		// Determine strength level
		let strength: PasswordValidationResult['strength'];
		if (score >= 4.5) strength = 'strong';
		else if (score >= 3.5) strength = 'good';
		else if (score >= 2.5) strength = 'fair';
		else if (score >= 1.5) strength = 'weak';
		else strength = 'very-weak';

		return {
			isValid: errors.length === 0 && score >= 4,
			errors,
			strength,
			score: Math.max(0, Math.min(5, score))
		};
	}

	/**
	 * Check for common weak patterns
	 */
	private static hasCommonPattern(password: string): boolean {
		const patterns = [
			/^(.)\1+$/, // All same character
			/123456/, // Sequential numbers
			/abcdef/i, // Sequential letters
			/qwerty/i, // Keyboard patterns
			/^password/i, // Starts with "password"
			/^\d+$/, // Only numbers
			/^[a-z]+$/i, // Only letters
		];

		return patterns.some(pattern => pattern.test(password));
	}

	/**
	 * Check if password has been pwned (simplified version)
	 * In production, this would call the Have I Been Pwned API
	 */
	static async checkPwnedPassword(password: string): Promise<{
		isPwned: boolean;
		breachCount?: number;
	}> {
		// TODO: Implement actual Have I Been Pwned API integration
		// For now, just check against our local common passwords list
		
		const isPwned = commonPasswords.has(password.toLowerCase());
		
		// Simulate API delay
		await new Promise(resolve => setTimeout(resolve, 200));
		
		return {
			isPwned,
			breachCount: isPwned ? 1 : 0
		};
	}

	/**
	 * Generate password strength suggestions
	 */
	static getStrengthSuggestions(password: string): string[] {
		const suggestions: string[] = [];
		
		if (password.length < 8) {
			suggestions.push('Make your password longer (at least 8 characters)');
		}
		
		if (!/[A-Z]/.test(password)) {
			suggestions.push('Add an uppercase letter');
		}
		
		if (!/[a-z]/.test(password)) {
			suggestions.push('Add a lowercase letter');
		}
		
		if (!/\d/.test(password)) {
			suggestions.push('Add a number');
		}
		
		if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
			suggestions.push('Add a special character (!@#$%^&*)');
		}
		
		if (this.hasCommonPattern(password)) {
			suggestions.push('Avoid common patterns like "123456" or "qwerty"');
		}
		
		if (commonPasswords.has(password.toLowerCase())) {
			suggestions.push('Choose a less common password');
		}
		
		if (password.length < 12) {
			suggestions.push('Consider making it even longer for better security');
		}
		
		return suggestions;
	}
}

export default PasswordValidator;