import{c as S,a as A,l as E}from"./CgY5D-bl.js";import{i as F}from"./BRn0EAu4.js";import{C as q,U as D,p as L,a as M,b as y,d as O,i as P,ax as U,aB as $,g as v,c as G,f as H,aC as J,F as C,aD as K,v as x,u as c,j as Q,r as R,x as T}from"./dabN1jmf.js";import{e as V,i as X}from"./BS_EoU4C.js";import{b as z,e as Y}from"./D6bItcHM.js";import{l as W,p as n}from"./D0VStH_y.js";function Z(a,e,t,u,r){q&&D();var i=e.$$slots?.[t],s=!1;i===!0&&(i=e[t==="default"?"children":t],s=!0),i===void 0?r!==null&&r(a):i(a,s?()=>u:u)}function de(a){const e={};a.children&&(e.default=!0);for(const t in a.$$slots)e[t]=!0;return e}/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const ee={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};m[C]="node_modules/lucide-svelte/dist/Icon.svelte";var te=A(K("<svg><!><!></svg>"),m[C],[[14,0]]);function m(a,e){S(new.target);const t=W(e,["children","$$slots","$$events","$$legacy"]),u=W(t,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);L(e,!1,m);let r=n(e,"name",8,void 0),i=n(e,"color",8,"currentColor"),s=n(e,"size",8,24),_=n(e,"strokeWidth",8,2),g=n(e,"absoluteStrokeWidth",8,!1),N=n(e,"iconNode",24,()=>[]);const p=(...l)=>l.filter((o,h,d)=>!!o&&T(d.indexOf(o),h)).join(" ");F();var f=te();z(f,(l,o)=>({...ee,...u,width:s(),height:s(),stroke:i(),"stroke-width":l,class:o}),[()=>(c(g()),c(_()),c(s()),x(()=>g()?Number(_())*24/Number(s()):_())),()=>(c(r()),c(t),x(()=>p("lucide-icon","lucide",r()?`lucide-${r()}`:"",t.class)))]);var k=P(f);M(()=>V(k,1,N,X,(l,o)=>{var h=U(()=>$(v(o),2));let d=()=>v(h)[0];d();let w=()=>v(h)[1];w();var b=G(),j=H(b);J(d),Y(j,d,!0,(B,ae)=>{z(B,()=>({...w()}))},void 0,[35,4]),y(l,b)}),"each",m,34,2);var I=Q(k);return Z(I,e,"default",{},null),R(f),y(a,f),O({...E()})}export{m as I,de as a,Z as s};
