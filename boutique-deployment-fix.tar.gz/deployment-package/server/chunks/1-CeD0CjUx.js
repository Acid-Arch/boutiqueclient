const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-BsgQQUHM.js')).default;
const imports = ["_app/immutable/nodes/1.D4PLfHeo.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DX-Oc8op.js","_app/immutable/chunks/3zx2OM-S.js","_app/immutable/chunks/CONSozIO.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-CeD0CjUx.js.map
