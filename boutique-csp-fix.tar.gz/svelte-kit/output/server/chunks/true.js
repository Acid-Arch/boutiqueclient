const DEV = true;
export {
  DEV as D
};
