import { D as DEV } from "./true.js";
const dev = DEV;
export {
  dev as d
};
