import"./DsnmJJEf.js";import"./DX-Oc8op.js";import{ai as w,g as h,s as q,aS as E,p as k,c as b,f as v,a as d,b as P,an as z,d as I,e as F,ao as G,r as H}from"./3zx2OM-S.js";import{I as D,s as R}from"./BID1lDIu.js";import{p,i as V,r as L,l as j,s as N,b as M}from"./Dwjkgfq3.js";import{b as x,r as A,c as y}from"./lPcixCUF.js";import{b as J,a as C}from"./CUm0MUH_.js";import{c as K}from"./ugyboSLg.js";import{a as O,c as Q,d as T,b as B,m as U}from"./BQu96azb.js";const W=Q({component:"label",parts:["root"]});class S{static create(e){return new S(e)}opts;attachment;constructor(e){this.opts=e,this.attachment=O(this.opts.ref),this.onmousedown=this.onmousedown.bind(this)}onmousedown(e){e.detail>1&&e.preventDefault()}#e=w(()=>({id:this.opts.id.current,[W.root]:"",onmousedown:this.onmousedown,...this.attachment}));get props(){return h(this.#e)}set props(e){q(this.#e,e)}}var X=I("<label><!></label>");function Y(l,e){const a=E();k(e,!0);let i=p(e,"id",19,()=>T(a)),o=p(e,"ref",15,null),c=L(e,["$$slots","$$events","$$legacy","children","child","id","ref","for"]);const s=S.create({id:B.with(()=>i()),ref:B.with(()=>o(),t=>o(t))}),n=w(()=>U(c,s.props,{for:e.for}));var m=b(),g=v(m);{var u=t=>{var f=b(),_=v(f);z(_,()=>e.child,()=>({props:h(n)})),d(t,f)},r=t=>{var f=X();x(f,()=>({...h(n),for:e.for}));var _=F(f);z(_,()=>e.children??G),H(f),d(t,f)};V(g,t=>{e.child?t(u):t(r,!1)})}d(l,m),P()}function de(l,e){const a=j(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const i=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}]];D(l,N({name:"mail"},()=>a,{get iconNode(){return i},children:(o,c)=>{var s=b(),n=v(s);R(n,e,"default",{},null),d(o,s)},$$slots:{default:!0}}))}function ce(l,e){const a=j(e,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.539.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const i=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];D(l,N({name:"shield"},()=>a,{get iconNode(){return i},children:(o,c)=>{var s=b(),n=v(s);R(n,e,"default",{},null),d(o,s)},$$slots:{default:!0}}))}var Z=I("<input/>"),$=I("<input/>");function ue(l,e){k(e,!0);let a=p(e,"ref",15,null),i=p(e,"value",15),o=p(e,"files",15),c=L(e,["$$slots","$$events","$$legacy","ref","value","type","files","class"]);var s=b(),n=v(s);{var m=u=>{var r=Z();A(r),x(r,t=>({"data-slot":"input",class:t,type:"file",...c}),[()=>y("selection:bg-primary dark:bg-input/30 selection:text-primary-foreground border-input ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 pt-1.5 text-sm font-medium outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",e.class)]),M(r,t=>a(t),()=>a()),J(r,o),C(r,i),d(u,r)},g=u=>{var r=$();A(r),x(r,t=>({"data-slot":"input",class:t,type:e.type,...c}),[()=>y("border-input bg-background selection:bg-primary dark:bg-input/30 selection:text-primary-foreground ring-offset-background placeholder:text-muted-foreground shadow-xs flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base outline-none transition-[color,box-shadow] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm","focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]","aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",e.class)]),M(r,t=>a(t),()=>a()),C(r,i),d(u,r)};V(n,u=>{e.type==="file"?u(m):u(g,!1)})}d(l,s),P()}function fe(l,e){k(e,!0);let a=p(e,"ref",15,null),i=L(e,["$$slots","$$events","$$legacy","ref","class"]);var o=b(),c=v(o);{let s=w(()=>y("flex select-none items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-50 group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50",e.class));K(c,()=>Y,(n,m)=>{m(n,N({"data-slot":"label",get class(){return h(s)}},()=>i,{get ref(){return a()},set ref(g){a(g)}}))})}d(l,o),P()}export{ue as I,fe as L,de as M,ce as S};
