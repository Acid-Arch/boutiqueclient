import { r as sanitize_props, p as push, t as spread_props, l as prevent_snippet_stringification, u as slot, f as pop, F as FILENAME, h as head, g as push_element, j as pop_element, O as attr, G as stringify, k as escape_html, o as ensure_array_like } from "../../../chunks/index3.js";
import { o as onDestroy, S as Separator } from "../../../chunks/separator.js";
import { C as Card, c as Card_content, a as Card_header, b as Card_title, d as Card_description } from "../../../chunks/card-title.js";
import "clsx";
import { B as Button, a as Badge } from "../../../chunks/badge.js";
import { R as Refresh_cw } from "../../../chunks/refresh-cw.js";
import { I as Icon } from "../../../chunks/Icon.js";
import { T as Triangle_alert } from "../../../chunks/triangle-alert.js";
import { A as Activity } from "../../../chunks/activity.js";
Circle_check[FILENAME] = "node_modules/lucide-svelte/dist/icons/circle-check.svelte";
function Circle_check($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Circle_check);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["circle", { "cx": "12", "cy": "12", "r": "10" }],
    ["path", { "d": "m9 12 2 2 4-4" }]
  ];
  Icon($$payload, spread_props([
    { name: "circle-check" },
    $$sanitized_props,
    {
      /**
       * @component @name CircleCheck
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KICA8cGF0aCBkPSJtOSAxMiAyIDIgNC00IiAvPgo8L3N2Zz4K) - https://lucide.dev/icons/circle-check
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Circle_check.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Clock[FILENAME] = "node_modules/lucide-svelte/dist/icons/clock.svelte";
function Clock($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Clock);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["path", { "d": "M12 6v6l4 2" }],
    ["circle", { "cx": "12", "cy": "12", "r": "10" }]
  ];
  Icon($$payload, spread_props([
    { name: "clock" },
    $$sanitized_props,
    {
      /**
       * @component @name Clock
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNMTIgNnY2bDQgMiIgLz4KICA8Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIxMCIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/clock
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Clock.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Database[FILENAME] = "node_modules/lucide-svelte/dist/icons/database.svelte";
function Database($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Database);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    ["ellipse", { "cx": "12", "cy": "5", "rx": "9", "ry": "3" }],
    ["path", { "d": "M3 5V19A9 3 0 0 0 21 19V5" }],
    ["path", { "d": "M3 12A9 3 0 0 0 21 12" }]
  ];
  Icon($$payload, spread_props([
    { name: "database" },
    $$sanitized_props,
    {
      /**
       * @component @name Database
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8ZWxsaXBzZSBjeD0iMTIiIGN5PSI1IiByeD0iOSIgcnk9IjMiIC8+CiAgPHBhdGggZD0iTTMgNVYxOUE5IDMgMCAwIDAgMjEgMTlWNSIgLz4KICA8cGF0aCBkPSJNMyAxMkE5IDMgMCAwIDAgMjEgMTIiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/database
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Database.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Server[FILENAME] = "node_modules/lucide-svelte/dist/icons/server.svelte";
function Server($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Server);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "rect",
      {
        "width": "20",
        "height": "8",
        "x": "2",
        "y": "2",
        "rx": "2",
        "ry": "2"
      }
    ],
    [
      "rect",
      {
        "width": "20",
        "height": "8",
        "x": "2",
        "y": "14",
        "rx": "2",
        "ry": "2"
      }
    ],
    ["line", { "x1": "6", "x2": "6.01", "y1": "6", "y2": "6" }],
    ["line", { "x1": "6", "x2": "6.01", "y1": "18", "y2": "18" }]
  ];
  Icon($$payload, spread_props([
    { name: "server" },
    $$sanitized_props,
    {
      /**
       * @component @name Server
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cmVjdCB3aWR0aD0iMjAiIGhlaWdodD0iOCIgeD0iMiIgeT0iMiIgcng9IjIiIHJ5PSIyIiAvPgogIDxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSI4IiB4PSIyIiB5PSIxNCIgcng9IjIiIHJ5PSIyIiAvPgogIDxsaW5lIHgxPSI2IiB4Mj0iNi4wMSIgeTE9IjYiIHkyPSI2IiAvPgogIDxsaW5lIHgxPSI2IiB4Mj0iNi4wMSIgeTE9IjE4IiB5Mj0iMTgiIC8+Cjwvc3ZnPgo=) - https://lucide.dev/icons/server
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Server.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
Zap[FILENAME] = "node_modules/lucide-svelte/dist/icons/zap.svelte";
function Zap($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push(Zap);
  /**
   * @license lucide-svelte v0.539.0 - ISC
   *
   * ISC License
   *
   * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
   *
   * Permission to use, copy, modify, and/or distribute this software for any
   * purpose with or without fee is hereby granted, provided that the above
   * copyright notice and this permission notice appear in all copies.
   *
   * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
   * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
   * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
   * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
   * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
   * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
   * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
   *
   */
  const iconNode = [
    [
      "path",
      {
        "d": "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"
      }
    ]
  ];
  Icon($$payload, spread_props([
    { name: "zap" },
    $$sanitized_props,
    {
      /**
       * @component @name Zap
       * @description Lucide SVG icon component, renders SVG Element with children.
       *
       * @preview ![img](data:image/svg+xml;base64,PHN2ZyAgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIgogIHdpZHRoPSIyNCIKICBoZWlnaHQ9IjI0IgogIHZpZXdCb3g9IjAgMCAyNCAyNCIKICBmaWxsPSJub25lIgogIHN0cm9rZT0iIzAwMCIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6ICNmZmY7IGJvcmRlci1yYWRpdXM6IDJweCIKICBzdHJva2Utd2lkdGg9IjIiCiAgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIgogIHN0cm9rZS1saW5lam9pbj0icm91bmQiCj4KICA8cGF0aCBkPSJNNCAxNGExIDEgMCAwIDEtLjc4LTEuNjNsOS45LTEwLjJhLjUuNSAwIDAgMSAuODYuNDZsLTEuOTIgNi4wMkExIDEgMCAwIDAgMTMgMTBoN2ExIDEgMCAwIDEgLjc4IDEuNjNsLTkuOSAxMC4yYS41LjUgMCAwIDEtLjg2LS40NmwxLjkyLTYuMDJBMSAxIDAgMCAwIDExIDE0eiIgLz4KPC9zdmc+Cg==) - https://lucide.dev/icons/zap
       * @see https://lucide.dev/guide/packages/lucide-svelte - Documentation
       *
       * @param {Object} props - Lucide icons props and any valid SVG attribute
       * @returns {FunctionalComponent} Svelte component
       *
       */
      iconNode,
      children: prevent_snippet_stringification(($$payload2) => {
        $$payload2.out.push(`<!---->`);
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out.push(`<!---->`);
      }),
      $$slots: { default: true }
    }
  ]));
  pop();
}
Zap.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
_page[FILENAME] = "src/routes/status/+page.svelte";
function _page($$payload, $$props) {
  push(_page);
  let healthStatus = null;
  let activeAlerts = null;
  let lastUpdated = "";
  let autoRefresh = true;
  let refreshInterval;
  let loading = true;
  let error = "";
  async function fetchHealthStatus() {
    try {
      const response = await fetch("/api/health?details=true&cache=false");
      if (response.ok) {
        healthStatus = await response.json();
        error = "";
      } else {
        error = `Health check failed: ${response.status}`;
        healthStatus = null;
      }
    } catch (e) {
      error = `Network error: ${e instanceof Error ? e.message : "Unknown error"}`;
      healthStatus = null;
    }
  }
  async function fetchAlerts() {
    try {
      const response = await fetch("/api/alerts?action=active");
      if (response.ok) {
        activeAlerts = await response.json();
      } else if (response.status !== 403) {
        console.warn("Failed to fetch alerts:", response.status);
      }
    } catch (e) {
      console.warn("Failed to fetch alerts:", e);
    }
  }
  async function refreshData() {
    loading = true;
    await Promise.all([fetchHealthStatus(), fetchAlerts()]);
    lastUpdated = (/* @__PURE__ */ new Date()).toLocaleTimeString();
    loading = false;
  }
  function getStatusIcon(status) {
    switch (status) {
      case "healthy":
      case "pass":
        return Circle_check;
      case "degraded":
      case "warn":
        return Triangle_alert;
      case "unhealthy":
      case "fail":
        return Triangle_alert;
      default:
        return Activity;
    }
  }
  function getStatusColor(status) {
    switch (status) {
      case "healthy":
      case "pass":
        return "text-green-600";
      case "degraded":
      case "warn":
        return "text-yellow-600";
      case "unhealthy":
      case "fail":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  }
  function getStatusBadgeVariant(status) {
    switch (status) {
      case "healthy":
      case "pass":
        return "default";
      case "degraded":
      case "warn":
        return "secondary";
      case "unhealthy":
      case "fail":
        return "destructive";
      default:
        return "outline";
    }
  }
  function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor(seconds % 86400 / 3600);
    const minutes = Math.floor(seconds % 3600 / 60);
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }
  function formatBytes(bytes) {
    const sizes = ["Bytes", "KB", "MB", "GB"];
    if (bytes === 0) return "0 Bytes";
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + " " + sizes[i];
  }
  function formatTimestamp(timestamp) {
    return new Date(timestamp).toLocaleString();
  }
  function getSeverityColor(severity) {
    switch (severity.toLowerCase()) {
      case "low":
        return "text-blue-600";
      case "medium":
        return "text-yellow-600";
      case "high":
        return "text-orange-600";
      case "critical":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  }
  onDestroy(() => {
    if (refreshInterval) {
      clearInterval(refreshInterval);
    }
  });
  if (!refreshInterval) {
    refreshInterval = setInterval(refreshData, 3e4);
  }
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>System Status - Client Portal</title>`;
  });
  $$payload.out.push(`<div class="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 p-6">`);
  push_element($$payload, "div", 193, 0);
  $$payload.out.push(`<div class="max-w-6xl mx-auto space-y-8">`);
  push_element($$payload, "div", 194, 1);
  $$payload.out.push(`<div class="text-center space-y-2">`);
  push_element($$payload, "div", 196, 2);
  $$payload.out.push(`<h1 class="text-3xl font-bold tracking-tight">`);
  push_element($$payload, "h1", 197, 3);
  $$payload.out.push(`System Status</h1>`);
  pop_element();
  $$payload.out.push(` <p class="text-muted-foreground">`);
  push_element($$payload, "p", 198, 3);
  $$payload.out.push(`Real-time monitoring and health information</p>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` <div class="flex items-center justify-between">`);
  push_element($$payload, "div", 202, 2);
  $$payload.out.push(`<div class="flex items-center gap-4">`);
  push_element($$payload, "div", 203, 3);
  Button($$payload, {
    disabled: loading,
    size: "sm",
    children: prevent_snippet_stringification(($$payload2) => {
      Refresh_cw($$payload2, {
        class: `h-4 w-4 mr-2 ${stringify(loading ? "animate-spin" : "")}`
      });
      $$payload2.out.push(`<!----> Refresh`);
    }),
    $$slots: { default: true }
  });
  $$payload.out.push(`<!----> <label class="flex items-center gap-2 text-sm">`);
  push_element($$payload, "label", 209, 4);
  $$payload.out.push(`<input type="checkbox"${attr("checked", autoRefresh, true)} class="rounded"/>`);
  push_element($$payload, "input", 210, 5);
  pop_element();
  $$payload.out.push(` Auto-refresh (30s)</label>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(` `);
  if (lastUpdated) {
    $$payload.out.push("<!--[-->");
    $$payload.out.push(`<div class="text-sm text-muted-foreground flex items-center gap-2">`);
    push_element($$payload, "div", 216, 4);
    Clock($$payload, { class: "h-4 w-4" });
    $$payload.out.push(`<!----> Last updated: ${escape_html(lastUpdated)}</div>`);
    pop_element();
  } else {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]--></div>`);
  pop_element();
  $$payload.out.push(` `);
  if (error) {
    $$payload.out.push("<!--[-->");
    Card($$payload, {
      class: "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950",
      children: prevent_snippet_stringification(($$payload2) => {
        Card_content($$payload2, {
          class: "p-6",
          children: prevent_snippet_stringification(($$payload3) => {
            $$payload3.out.push(`<div class="flex items-center gap-2 text-red-700 dark:text-red-300">`);
            push_element($$payload3, "div", 226, 5);
            Triangle_alert($$payload3, { class: "h-5 w-5" });
            $$payload3.out.push(`<!----> <span class="font-medium">`);
            push_element($$payload3, "span", 228, 6);
            $$payload3.out.push(`Error</span>`);
            pop_element();
            $$payload3.out.push(`</div>`);
            pop_element();
            $$payload3.out.push(` <p class="mt-2 text-red-600 dark:text-red-400">`);
            push_element($$payload3, "p", 230, 5);
            $$payload3.out.push(`${escape_html(error)}</p>`);
            pop_element();
          }),
          $$slots: { default: true }
        });
      }),
      $$slots: { default: true }
    });
  } else {
    $$payload.out.push("<!--[!-->");
    if (healthStatus) {
      $$payload.out.push("<!--[-->");
      Card($$payload, {
        class: `border-2 ${stringify(healthStatus.status === "healthy" ? "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950" : healthStatus.status === "degraded" ? "border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950" : "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950")}`,
        children: prevent_snippet_stringification(($$payload2) => {
          Card_content($$payload2, {
            class: "p-8",
            children: prevent_snippet_stringification(($$payload3) => {
              $$payload3.out.push(`<div class="flex items-center justify-between">`);
              push_element($$payload3, "div", 237, 5);
              $$payload3.out.push(`<div class="flex items-center gap-4">`);
              push_element($$payload3, "div", 238, 6);
              $$payload3.out.push(`<!---->`);
              getStatusIcon(healthStatus.status)?.($$payload3, {
                class: `h-12 w-12 ${stringify(getStatusColor(healthStatus.status))}`
              });
              $$payload3.out.push(`<!----> <div>`);
              push_element($$payload3, "div", 240, 7);
              $$payload3.out.push(`<h2 class="text-2xl font-bold">`);
              push_element($$payload3, "h2", 241, 8);
              $$payload3.out.push(`System ${escape_html(healthStatus.status === "healthy" ? "Operational" : healthStatus.status === "degraded" ? "Degraded" : "Down")}</h2>`);
              pop_element();
              $$payload3.out.push(` <p class="text-muted-foreground">`);
              push_element($$payload3, "p", 242, 8);
              $$payload3.out.push(`All systems are ${escape_html(healthStatus.status)}</p>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` <div class="text-right space-y-2">`);
              push_element($$payload3, "div", 246, 6);
              $$payload3.out.push(`<div class="text-sm text-muted-foreground">`);
              push_element($$payload3, "div", 247, 7);
              $$payload3.out.push(`Version: ${escape_html(healthStatus.version)}</div>`);
              pop_element();
              $$payload3.out.push(` <div class="text-sm text-muted-foreground">`);
              push_element($$payload3, "div", 248, 7);
              $$payload3.out.push(`Environment: ${escape_html(healthStatus.environment)}</div>`);
              pop_element();
              $$payload3.out.push(` <div class="text-sm text-muted-foreground">`);
              push_element($$payload3, "div", 249, 7);
              $$payload3.out.push(`Uptime: ${escape_html(formatUptime(healthStatus.uptime))}</div>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
            }),
            $$slots: { default: true }
          });
        }),
        $$slots: { default: true }
      });
      $$payload.out.push(`<!----> <div class="grid grid-cols-1 md:grid-cols-3 gap-6">`);
      push_element($$payload, "div", 256, 3);
      Card($$payload, {
        children: prevent_snippet_stringification(($$payload2) => {
          Card_header($$payload2, {
            class: "pb-3",
            children: prevent_snippet_stringification(($$payload3) => {
              Card_title($$payload3, {
                class: "flex items-center gap-2",
                children: prevent_snippet_stringification(($$payload4) => {
                  Database($$payload4, { class: "h-5 w-5" });
                  $$payload4.out.push(`<!----> Database`);
                }),
                $$slots: { default: true }
              });
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!----> `);
          Card_content($$payload2, {
            children: prevent_snippet_stringification(($$payload3) => {
              $$payload3.out.push(`<div class="flex items-center justify-between">`);
              push_element($$payload3, "div", 265, 6);
              Badge($$payload3, {
                variant: getStatusBadgeVariant(healthStatus.checks.database.status),
                children: prevent_snippet_stringification(($$payload4) => {
                  $$payload4.out.push(`<!---->${escape_html(healthStatus.checks.database.status)}`);
                }),
                $$slots: { default: true }
              });
              $$payload3.out.push(`<!----> <span class="text-sm text-muted-foreground">`);
              push_element($$payload3, "span", 269, 7);
              $$payload3.out.push(`${escape_html(healthStatus.checks.database.responseTime)}ms</span>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` `);
              if (healthStatus.checks.database.message) {
                $$payload3.out.push("<!--[-->");
                $$payload3.out.push(`<p class="mt-2 text-sm text-muted-foreground">`);
                push_element($$payload3, "p", 274, 7);
                $$payload3.out.push(`${escape_html(healthStatus.checks.database.message)}</p>`);
                pop_element();
              } else {
                $$payload3.out.push("<!--[!-->");
              }
              $$payload3.out.push(`<!--]-->`);
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!---->`);
        }),
        $$slots: { default: true }
      });
      $$payload.out.push(`<!----> `);
      Card($$payload, {
        children: prevent_snippet_stringification(($$payload2) => {
          Card_header($$payload2, {
            class: "pb-3",
            children: prevent_snippet_stringification(($$payload3) => {
              Card_title($$payload3, {
                class: "flex items-center gap-2",
                children: prevent_snippet_stringification(($$payload4) => {
                  Server($$payload4, { class: "h-5 w-5" });
                  $$payload4.out.push(`<!----> Memory`);
                }),
                $$slots: { default: true }
              });
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!----> `);
          Card_content($$payload2, {
            children: prevent_snippet_stringification(($$payload3) => {
              $$payload3.out.push(`<div class="flex items-center justify-between">`);
              push_element($$payload3, "div", 287, 6);
              Badge($$payload3, {
                variant: getStatusBadgeVariant(healthStatus.checks.memory.status),
                children: prevent_snippet_stringification(($$payload4) => {
                  $$payload4.out.push(`<!---->${escape_html(healthStatus.checks.memory.status)}`);
                }),
                $$slots: { default: true }
              });
              $$payload3.out.push(`<!----> <span class="text-sm text-muted-foreground">`);
              push_element($$payload3, "span", 291, 7);
              $$payload3.out.push(`${escape_html(healthStatus.checks.memory.responseTime)}ms</span>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` `);
              if (healthStatus.checks.memory.message) {
                $$payload3.out.push("<!--[-->");
                $$payload3.out.push(`<p class="mt-2 text-sm text-muted-foreground">`);
                push_element($$payload3, "p", 296, 7);
                $$payload3.out.push(`${escape_html(healthStatus.checks.memory.message)}</p>`);
                pop_element();
              } else {
                $$payload3.out.push("<!--[!-->");
              }
              $$payload3.out.push(`<!--]-->`);
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!---->`);
        }),
        $$slots: { default: true }
      });
      $$payload.out.push(`<!----> `);
      Card($$payload, {
        children: prevent_snippet_stringification(($$payload2) => {
          Card_header($$payload2, {
            class: "pb-3",
            children: prevent_snippet_stringification(($$payload3) => {
              Card_title($$payload3, {
                class: "flex items-center gap-2",
                children: prevent_snippet_stringification(($$payload4) => {
                  Zap($$payload4, { class: "h-5 w-5" });
                  $$payload4.out.push(`<!----> Performance`);
                }),
                $$slots: { default: true }
              });
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!----> `);
          Card_content($$payload2, {
            children: prevent_snippet_stringification(($$payload3) => {
              $$payload3.out.push(`<div class="space-y-2">`);
              push_element($$payload3, "div", 309, 6);
              $$payload3.out.push(`<div class="flex justify-between">`);
              push_element($$payload3, "div", 310, 7);
              $$payload3.out.push(`<span class="text-sm">`);
              push_element($$payload3, "span", 311, 8);
              $$payload3.out.push(`Response Time</span>`);
              pop_element();
              $$payload3.out.push(` <span class="text-sm font-mono">`);
              push_element($$payload3, "span", 312, 8);
              $$payload3.out.push(`${escape_html(healthStatus.performance.responseTime)}ms</span>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` <div class="flex justify-between">`);
              push_element($$payload3, "div", 314, 7);
              $$payload3.out.push(`<span class="text-sm">`);
              push_element($$payload3, "span", 315, 8);
              $$payload3.out.push(`Memory Usage</span>`);
              pop_element();
              $$payload3.out.push(` <span class="text-sm font-mono">`);
              push_element($$payload3, "span", 316, 8);
              $$payload3.out.push(`${escape_html(formatBytes(healthStatus.performance.memoryUsage.heapUsed))}</span>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(` <div class="flex justify-between">`);
              push_element($$payload3, "div", 318, 7);
              $$payload3.out.push(`<span class="text-sm">`);
              push_element($$payload3, "span", 319, 8);
              $$payload3.out.push(`Total Heap</span>`);
              pop_element();
              $$payload3.out.push(` <span class="text-sm font-mono">`);
              push_element($$payload3, "span", 320, 8);
              $$payload3.out.push(`${escape_html(formatBytes(healthStatus.performance.memoryUsage.heapTotal))}</span>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
              $$payload3.out.push(`</div>`);
              pop_element();
            }),
            $$slots: { default: true }
          });
          $$payload2.out.push(`<!---->`);
        }),
        $$slots: { default: true }
      });
      $$payload.out.push(`<!----></div>`);
      pop_element();
      $$payload.out.push(` `);
      if (activeAlerts && activeAlerts.count > 0) {
        $$payload.out.push("<!--[-->");
        Card($$payload, {
          children: prevent_snippet_stringification(($$payload2) => {
            Card_header($$payload2, {
              children: prevent_snippet_stringification(($$payload3) => {
                Card_title($$payload3, {
                  class: "flex items-center gap-2",
                  children: prevent_snippet_stringification(($$payload4) => {
                    Triangle_alert($$payload4, { class: "h-5 w-5 text-red-600" });
                    $$payload4.out.push(`<!----> Active Alerts (${escape_html(activeAlerts.count)})`);
                  }),
                  $$slots: { default: true }
                });
                $$payload3.out.push(`<!----> `);
                Card_description($$payload3, {
                  children: prevent_snippet_stringification(($$payload4) => {
                    $$payload4.out.push(`<!---->System alerts requiring attention`);
                  }),
                  $$slots: { default: true }
                });
                $$payload3.out.push(`<!---->`);
              }),
              $$slots: { default: true }
            });
            $$payload2.out.push(`<!----> `);
            Card_content($$payload2, {
              children: prevent_snippet_stringification(($$payload3) => {
                const each_array = ensure_array_like(activeAlerts.alerts);
                $$payload3.out.push(`<div class="space-y-4">`);
                push_element($$payload3, "div", 338, 6);
                $$payload3.out.push(`<!--[-->`);
                for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                  let alert = each_array[$$index];
                  $$payload3.out.push(`<div class="border rounded-lg p-4 space-y-2">`);
                  push_element($$payload3, "div", 340, 8);
                  $$payload3.out.push(`<div class="flex items-center justify-between">`);
                  push_element($$payload3, "div", 341, 9);
                  $$payload3.out.push(`<h4 class="font-semibold">`);
                  push_element($$payload3, "h4", 342, 10);
                  $$payload3.out.push(`${escape_html(alert.title)}</h4>`);
                  pop_element();
                  $$payload3.out.push(` <div class="flex items-center gap-2">`);
                  push_element($$payload3, "div", 343, 10);
                  Badge($$payload3, {
                    variant: "outline",
                    class: getSeverityColor(alert.severity),
                    children: prevent_snippet_stringification(($$payload4) => {
                      $$payload4.out.push(`<!---->${escape_html(alert.severity)}`);
                    }),
                    $$slots: { default: true }
                  });
                  $$payload3.out.push(`<!----> <span class="text-xs text-muted-foreground">`);
                  push_element($$payload3, "span", 347, 11);
                  $$payload3.out.push(`${escape_html(formatTimestamp(alert.timestamp))}</span>`);
                  pop_element();
                  $$payload3.out.push(`</div>`);
                  pop_element();
                  $$payload3.out.push(`</div>`);
                  pop_element();
                  $$payload3.out.push(` <p class="text-sm text-muted-foreground">`);
                  push_element($$payload3, "p", 352, 9);
                  $$payload3.out.push(`${escape_html(alert.message)}</p>`);
                  pop_element();
                  $$payload3.out.push(`</div>`);
                  pop_element();
                }
                $$payload3.out.push(`<!--]--></div>`);
                pop_element();
              }),
              $$slots: { default: true }
            });
            $$payload2.out.push(`<!---->`);
          }),
          $$slots: { default: true }
        });
      } else {
        $$payload.out.push("<!--[!-->");
        if (activeAlerts) {
          $$payload.out.push("<!--[-->");
          Card($$payload, {
            children: prevent_snippet_stringification(($$payload2) => {
              Card_content($$payload2, {
                class: "p-8 text-center",
                children: prevent_snippet_stringification(($$payload3) => {
                  Circle_check($$payload3, { class: "h-12 w-12 text-green-600 mx-auto mb-4" });
                  $$payload3.out.push(`<!----> <h3 class="text-lg font-semibold mb-2">`);
                  push_element($$payload3, "h3", 362, 6);
                  $$payload3.out.push(`No Active Alerts</h3>`);
                  pop_element();
                  $$payload3.out.push(` <p class="text-muted-foreground">`);
                  push_element($$payload3, "p", 363, 6);
                  $$payload3.out.push(`All systems are operating normally</p>`);
                  pop_element();
                }),
                $$slots: { default: true }
              });
            }),
            $$slots: { default: true }
          });
        } else {
          $$payload.out.push("<!--[!-->");
        }
        $$payload.out.push(`<!--]-->`);
      }
      $$payload.out.push(`<!--]-->`);
    } else {
      $$payload.out.push("<!--[!-->");
      if (loading) {
        $$payload.out.push("<!--[-->");
        $$payload.out.push(`<div class="text-center py-12">`);
        push_element($$payload, "div", 369, 3);
        Refresh_cw($$payload, { class: "h-8 w-8 animate-spin mx-auto mb-4" });
        $$payload.out.push(`<!----> <p class="text-muted-foreground">`);
        push_element($$payload, "p", 371, 4);
        $$payload.out.push(`Loading system status...</p>`);
        pop_element();
        $$payload.out.push(`</div>`);
        pop_element();
      } else {
        $$payload.out.push("<!--[!-->");
      }
      $$payload.out.push(`<!--]-->`);
    }
    $$payload.out.push(`<!--]-->`);
  }
  $$payload.out.push(`<!--]--> `);
  Separator($$payload, {});
  $$payload.out.push(`<!----> <div class="text-center text-sm text-muted-foreground">`);
  push_element($$payload, "div", 377, 2);
  $$payload.out.push(`<p>`);
  push_element($$payload, "p", 378, 3);
  $$payload.out.push(`System monitoring powered by internal health checks and alerting system</p>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  $$payload.out.push(`</div>`);
  pop_element();
  pop();
}
_page.render = function() {
  throw new Error("Component.render(...) is no longer valid in Svelte 5. See https://svelte.dev/docs/svelte/v5-migration-guide#Components-are-no-longer-classes for more information");
};
export {
  _page as default
};
