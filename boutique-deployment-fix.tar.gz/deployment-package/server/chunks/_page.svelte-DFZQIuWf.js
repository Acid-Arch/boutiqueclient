import { p as push, m as head, j as pop } from './index3-0vHBXF6s.js';
import 'clsx';
import './badge-DNI7Aq68.js';
import './false-B2gHlHjM.js';
import 'tailwind-merge';

function _page($$payload, $$props) {
  push();
  head($$payload, ($$payload2) => {
    $$payload2.title = `<title>Design System - Client Portal</title>`;
  });
  {
    $$payload.out.push("<!--[!-->");
  }
  $$payload.out.push(`<!--]-->`);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DFZQIuWf.js.map
