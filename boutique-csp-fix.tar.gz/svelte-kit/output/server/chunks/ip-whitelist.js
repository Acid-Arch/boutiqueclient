import { g as getIPWhitelistConfig } from "./ip-utils.js";
import pg from "pg";
const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});
const whitelistCache = /* @__PURE__ */ new Map();
async function validateIPAccess(request, userId, userEmail) {
  getIPWhitelistConfig();
  {
    return {
      allowed: true,
      publicIP: null,
      source: "disabled",
      reason: "IP whitelist is disabled"
    };
  }
}
async function recordFailedAttempt(publicIP, userId) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(`
      INSERT INTO ip_rate_limits (ip_address, failed_attempts, last_attempt) 
      VALUES ($1, 1, NOW())
      ON CONFLICT (ip_address) 
      DO UPDATE SET 
        failed_attempts = ip_rate_limits.failed_attempts + 1,
        last_attempt = NOW()
    `, [publicIP]);
    if (userId) ;
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Failed to record failed attempt:", error);
  } finally {
    client.release();
  }
}
async function addIPToWhitelist(address, description, userId, createdBy, expiresAt = null) {
  const client = await pool.connect();
  try {
    const result = await client.query(`
      INSERT INTO ip_whitelist (address, description, user_id, created_by, expires_at)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id
    `, [address, description, userId, createdBy, expiresAt]);
    clearCacheForIP(address);
    return { success: true, id: result.rows[0].id };
  } catch (error) {
    console.error("Failed to add IP to whitelist:", error);
    return { success: false, error: error.message };
  } finally {
    client.release();
  }
}
async function removeIPFromWhitelist(id) {
  const client = await pool.connect();
  try {
    await client.query("DELETE FROM ip_whitelist WHERE id = $1", [id]);
    whitelistCache.clear();
    return { success: true };
  } catch (error) {
    console.error("Failed to remove IP from whitelist:", error);
    return { success: false, error: error.message };
  } finally {
    client.release();
  }
}
function clearCacheForIP(address) {
  whitelistCache.clear();
}
export {
  addIPToWhitelist as a,
  recordFailedAttempt as b,
  removeIPFromWhitelist as r,
  validateIPAccess as v
};
